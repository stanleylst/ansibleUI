<?php
/**
* Created by PhpStorm.
* User: rxh7453
* Date: 2016/1/11
* Time: 18:09
*/
class lst {
    public  static function query($log){
        return strpos($log['message'],'支付银行卡与恒生不符')!==false;
    }
    public  static function cfsesrver($log){
        return strpos($log['message'],'财富服务未开通')!==false;
    }
    public  static function cardDiff($log){
        return strpos($log['message'],'用户在一号通的银行卡与恒生不一致')!==false;
    }
     public  static function payerror($log){
        return strpos($log['message'],'订单请求java订单支付成功接口[fund.settle.order.state]失败')!==false;
    }
     public  static function phoneerror($log){
        return strpos($log['message'],'变更手机号失败')!==false;
    }
  //   public  static function faerror1($log){        //因业务需要会误报较多，暂时忽略
  //      return strpos($log['message'],'绑定理财师失败')!==false;
  //  }    
     public  static function caifunull($log){
        return strpos($log['message'],'RegYht开通财富服务失败')!==false;
    }
     public  static function jigounull($log){
        return strpos($log['message'],'查不到机构信息')!==false;
    }
     public  static function hserror1($log){
        return strpos($log['message'],'恒生开户队列执行异常')!==false;
    }
     public  static function hserror2($log){
        return strpos($log['message'],'HS返回结果异常')!==false;
    }
     public  static function hspush($log){
        return false !== strpos(json_encode($log['context']), 'HSOrderQueue');  //恒生推送异常
    }
     public  static function erppush($log){
        return false !== strpos(json_encode($log['context']), 'ErpOrderQueue');  //ERP推送异常
    }    
     public  static function iderror($log){
        return strpos($log['message'],'修改yht证件有效期参数参数有误')!==false;
    }
     public  static function yhterror1($log){
        return strpos($log['message'],'查询一号通信息出错')!==false;
    }
      public  static function yhterror2($log){
        return strpos($log['message'],'同步失败')!==false; //财师信息[XXXX]同步失败
    }             public  static function yhterror3($log){
        return strpos($log['message'],'一号通给的省份为空')!==false; //财师信息[XXXX]同步失败
    }  
     public  static function cpfserror($log){
        return strpos($log['message'],'CpSite::defaultError')!==false;
    }
     public  static function javaorder($log){
        return strpos($log['message'],'订单请求java订单支付成功接口[fund.settle.order.state]失败')!==false;
    }
     public  static function satest($log){
        //return $log['message'] == '[运维检测]告警状态正常'; //留一个全量筛选模板
        return strpos($log['message'],'[运维检测]告警状态正常')!==false;
    }
}
