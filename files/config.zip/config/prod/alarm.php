<?php

 

return [

    'toolDir' => '/srv/www/config/',

   // 'commonUser' => [

   //     '13818909463', //mc

   //      '18717740292', //lisongtao

   //     '18521709092',//sunyifei

   // ],

    'project' => [

 

        'order'=>[         //订单和恒生及erp推送

            '18521358271', //黄超
            
            'wx:?SCU1000T1e40c40f579b2a1ccd1f5fc97c83d4a056e01c3a016b0',//相明才

             '13917320711',//阿火

            // '18101879892', //吴益

            // '15618273535', //范磊

            // '13916720840', //邵力

            // '13817529000', //张皓

        ],

        'cp2fs'=>[         //金融后台

               '18701737301',//胡文芳

               '18521358271', //黄超

        ],

        'pay'=>[          //交易支付

                '15730255292',//彭郢

                '18521358271', //黄超

        ], 



        'java1'=>[        //java订单

                '15658068593',//赖睿甫

                '18616020246',//魏书伟

          //  '18521358271', //黄超

        ],



       'user'=>[          //用户相关告警,版本发布及CRM落地期间暂停

                '13764141151',//礼俊

                '18637198796',//郭士魁

               // '18521358271', //chao

        ],



        'satest'=>[        //检测sms告警存活状态

     	        '18717740292', //lisongtao

                '13917320711',//阿火

	            '18521709092',//sunyifei
	            
	            'wx:?SCU1001Tba96523b5d71b693abb7fb9ee31e141056e02068819d4',//孙毅飞

	            //'13818909463', //mc
              'wx:?SCU601Td7f11872765010e22ef81bf5bb53fa615612642a1d4c5',//王心远

        ],

 

    ],
    
    
    //全局通配告警对象
        'commonUser' => [

        //'13818909463', //mc
        'wx:?SCU601Td7f11872765010e22ef81bf5bb53fa615612642a1d4c5',//王心远

        '18717740292', //lisongtao
       'wx:?SCU1001Tba96523b5d71b693abb7fb9ee31e141056e02068819d4',//孙毅飞
        '18521709092',//sunyifei

    ],

    'order' =>

    [

        ["lst", 'query'],

        ["lst", 'hspush'], 

        ["lst", 'erppush'],

    ],

    'user' =>

    [

        ["lst", 'cardDiff'],

        ["lst", 'cfsesrver'],

        ["lst", 'phoneerror'],

        ["lst", 'caifunull'],

        ["lst", 'hserror1'],

        ["lst", 'hserror2'],

        ["lst", 'jigounull'],

        ["lst", 'iderror'],

        ["lst", 'yhterror1'],

        ["lst", 'yhterror2'],
        
        ["lst", 'yhterror3'],

        //["lst", 'faerror1'], //用户通过理财师邀请链接注册方舟第一次会还未开户完成但是理财师自动绑定失败，误报较多先保留

    ],

    'pay' =>

    [

        ["lst", 'payerror'],

    ],

    'cp2fs' =>

    [

        ["lst", 'cpfserror'],

    ],

    'java1' =>

    [

        ["lst", 'javaorder'],

    ],

    'satest' =>

    [

        ["lst", 'satest'],

    ],



];




