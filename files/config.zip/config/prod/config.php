<?php
use Common\Utility\IdGenerator;
use King\Core\JTPay\JTAuth;
use King\Core\JTPay\JTPay;
use King\Core\Uploader\QiniuUploader;

return [
    'pdo' => [
        'dsn' => 'mysql:host=10.3.6.28:1331;dbname=king',
        'username' => 'ifa-pro',
        'password' => '1Zx8Ltw2F6Ex',
    ],
    'dzh-pdo' => [
        'dsn' => 'mysql:host=10.3.6.34:1331;dbname=caihui_1',
        'username' => 'ifa-pro',
        'password' => '1Zx8Ltw2F6Ex',
    ],    
    'rabbitmq' => [
        'host' => '10.3.6.27',
        'port' => 5672,
        'username' => 'king',
        'password' => 'king-ifa3',
        'vhost' => '/',
    ],
    'predis' => [
        [
            'scheme' => 'tcp',
            'host' => '10.3.6.24',
            'port' => 6379,
            'password' => 'c2ea95d84217cd56092bc3e56cd55864',
        ],
        null,
    ],
    'mongo' => ['mongodb://ifa-pro:oSiNKxZ2saJj@10.3.6.24:2331/king', []],
] + [
    'voice' => [
        'accountSid' => '8a48b5514d32a2a8014d32cbed750044',//主帐号
        'accountToken' => '630465539a774b7c8f600669276b4344',//主帐号Token
        'appId' => 'aaf98f894d328b13014d32d7cacd00aa',//应用Id
        'serverIP' => 'app.cloopen.com',//请求地址，格式如左，不需要写https://
        'serverPort' => '8883',//请求端口
        'softVersion' => '2013-12-26',//版本号
        'playTimes' => 3,//播放次数
        'displayNum' => '400-829-8358',//显示的主叫号码, 需要提交带有公章的承诺函 扫描件，对方审批通过后才可用，所以此处配置没用，可去除--comment by eaglegends on 2015.07.15
        'respUrl' => '',//语音验证码状态通知回调地址，云通讯平台将向该Url地址发送呼叫结果通知
    ],
    'sms' => [
        'priority' => [
            'mwkj' => 3,
            'ytzy' => 2,
            'ytyd' => 1
        ],
        'provider' => [
            //梦网科技
            'mwkj' => [
                'name' => '梦网科技',
                'apiURL' => 'http://61.130.7.220:8023/MWGate/wmgw.asmx/',
                'userId' => 'J50336',
                'password' => '269376',
                'needBrands' => 0, //是否显示品牌名称(即 短信签名)
            ],
            //移通自有通道
            'ytzy' => [
                'name' => '移通自有通道',
                'apiURL' => 'http://esms.etonenet.com/sms/mt',
                'userId' => '6824',
                'password' => 'ny68fz30',
                'needBrands' => 0,
            ],
            //移通移动通道
            'ytyd' => [
                'name' => '移通移动通道',
                'apiURL' => 'http://esms.etonenet.com/sms/mt',
                'userId' => '6824',
                'password' => 'ny68fz30',
                'needBrands' => 0,
            ]
        ]
    ],
    //彭郢 2016-01-25 亿业邮件服务商添加
    'mail' => [
        'host' => 'smtp.easeye.com.cn',
        'port' => 27,
        'user' => 'lisongtao@noah-fund.com',
        'pwd' => 'yiyesupport@noah-fund.com',
        'from' => 'support@customer.ifaclub.com',
        'fromName' => '财富方舟',
    ],
    'crm' => [
        'crmUrl' => 'http://10.3.210.51:8080/wsproj/services/sFOutboundWSBean?wsdl',
        'obtype1__c' => '理财师分配',
        'obtype2__c' => 'O2O微诺-预约理财师',
        'obstatus__c' => '0',
        'memo__c' => '',
    ],

    'jtpay' => [
        'pay_money_min' => 11,//小额打款确认最小额,以分为单位
        'pay_money_max' => 99,//小额打款确认最大额，以分为单位
        JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA7d1QGcOil1ojxXNZpTXW+gxSwRA1vlZH3IsDiqjtmgNPVCHl
ubvzT78098+XlBcxzlnVXBTmKTrO1ALF9DoX6ETEs/8Hqzbz8UjdXbtwhMtPBZmL
5siaszLutl/ZKDa4k5ZsATFZ4a3HzV6zMrL27nLfuKd579oMEadbcAVQK0/Xfchn
Jn1oAER47OVdbnMGwIsosIwc0x+Yd7TP/R1WEReu6E5lmbzqXUkkXc/hZaEH34DT
A05ch+GZvi5ixVgA0UI8XvRDDlb8iDHVy6HaecBT5/NRBEWOKqXxOeJQXoqRPOpP
62hdyUMkPtczCXB4J7H50s1zenhL2Uw3kP3rTwIDAQABAoIBAQCJ/DK1X3n4lv/d
URcV8e+tymxPNxoWOnMhizsYuvpqt7TTN37OiiuRfXg6saBa9kGcVRyieDU0gbrt
3lX7YZ/wy8PYLv/B4PUOaZiRAWU6g75pnzM7Q/AKOGemQF/3JhdY9o/c+UYM1wTr
LB6EMLFyjg0eT3k7HKCXtSAkEdD57g61BOcNn9FlXHflEyb4m8XcFBi0FAn5R9Hu
j8IoHBiCJMgMNcMwpvdxRz8syUluDtos3c+gRA+J0ScPecC34UxTkdIbRiuSPcAn
be3JPYeDX0JgLcVAL4JiKlDD7e67wL/Nik1OgqZ8cA/4/D+qN4mnT+/4R7WOyJLu
9kepyseRAoGBAP/XHm4UcmSCgMeSA/lIvFU60jG/Zu1smBboV9OfSFtZjrBgwV7E
KRqg9cs4vSdHp0y/Qn19OqfjcB9QM593a778+k2Xrn3D5a2LHg6DhI/zo30uuUHe
lR8hFphtDIsdG7pammAUgPlbWzwZrQUBJ8MaXaaQc0lmde5+H/oBKPFjAoGBAO4D
Ulc3hEQxmCGN38LnprtGEBfCt+ywJJuFvHbTXAMJwgAEh1xqjTmuaMIYZbYKeROD
hklcvAV14dR+pYbrYetqymSHdmwe+YcV3rj4tz6IKv6eE2KJfYKRLzl1xxYyO1tc
JncgZS8GLVCF8HfRC+c5u93gbv/XZFrM7EewU1glAoGALB7HCqjQCXFQEBqoQMdA
Y1pfgWDGuU8u81RiQQaJDefl6ZjmABfIFuWHPeKtDCcZPO0G5GlCQk3AukW0gV2w
4SDzcYok919fLox9RHd91u1nVmFGZYujH9ku8l5r+VmtvHd/g+5FR7tvgm/THLfU
SZs0Z1Ml7pSS5ewuS4kDrI0CgYAAk9N8UK8qdzBWTIDReTxnUekyFY/arCa6ld16
MFMV0s08sMYfTEbhb/HjHqoIggf/Kx+FSAtQvBN7L395T1LiflTVX5rC8mRKlpv+
uOPA7BWmnn2PjKPYUD/cFNQR0rdgJl4VheeY8JvliR2nPMOZoQM6q5O5XS1qJvsf
xWa+XQKBgDDt8OdRRzDvA7b+u6v+MKURuZqa7l75ThUGVs3rtAz5Om/oXFn6RsYI
6DrsDreeT8kKasstxkslGm+b17GGUD8eBfQ8REEDsu5FYM/h/P7Ut49S3AuE19NH
AIAi7cXz41zQrNHBIj5I/Kmazj2WDdrAeT1kOMSf1aVm/BDK7kz0
-----END RSA PRIVATE KEY-----
KEY
        /*
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7d1QGcOil1ojxXNZpTXW
+gxSwRA1vlZH3IsDiqjtmgNPVCHlubvzT78098+XlBcxzlnVXBTmKTrO1ALF9DoX
6ETEs/8Hqzbz8UjdXbtwhMtPBZmL5siaszLutl/ZKDa4k5ZsATFZ4a3HzV6zMrL2
7nLfuKd579oMEadbcAVQK0/XfchnJn1oAER47OVdbnMGwIsosIwc0x+Yd7TP/R1W
EReu6E5lmbzqXUkkXc/hZaEH34DTA05ch+GZvi5ixVgA0UI8XvRDDlb8iDHVy6Ha
ecBT5/NRBEWOKqXxOeJQXoqRPOpP62hdyUMkPtczCXB4J7H50s1zenhL2Uw3kP3r
TwIDAQAB
-----END PUBLIC KEY-----
         */
        ,
        JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzlVpTEUUZYJhwt/pLar5
2TAPAd2dWYC/51NeLUenonCMYu8NqzvWPc+7SoDIKTS1mT/FsGSGu+zxSgYfcwd9
1SwB8Gct/y6N1r7emVpZ+agkhv23NU4Yv1z0kSp79yq66fO+Mws9TE0IeBualq+9
B5PU1i1tECghcG3AndQfrRsDoM3xJWRyr5ee2OTQuaKmKKuIM0twI0dwXO7ENGL9
JHz4VPyKSZ36YGhv5iNBb4pIebWBiVhWdIwm/u4n9sIZRK6iGB2Cvmk7JQnKxS6F
MvUDS3xxIOBd6xXtETHUQE1UN3+jIVzBhNlnuG4wIBdRwFF8a6XP80ZsE1os9z7A
3wIDAQAB
-----END PUBLIC KEY-----
KEY
        ,
        JTPay::CFG_JT_MERID => '631310060050017',
        JTPay::CFG_JT_MERNAME => '诺亚方舟（上海）金融信息服务有限公司',
        JTPay::CFG_JT_HOST => '10.198.4.102',
        JTPay::CFG_JT_PORT => 9521,
        JTPay::CFG_TIMEOUT => 5,
        JTPay::CFG_BILL_PATH => '/srv/jtpay',
        JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
        'sn' => [
            IdGenerator::CFG_MAX => 80999999,
            IdGenerator::CFG_PREFIX => 'jtpay:' . date('Ymd'),
            IdGenerator::CFG_EXPIRE => 129600,//1.5天
        ],
    ],
    'jtpaySplit' => [
        'pay_money_min' => 11,//小额打款确认最小额,以分为单位
        'pay_money_max' => 99,//小额打款确认最大额，以分为单位
        JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA7d1QGcOil1ojxXNZpTXW+gxSwRA1vlZH3IsDiqjtmgNPVCHl
ubvzT78098+XlBcxzlnVXBTmKTrO1ALF9DoX6ETEs/8Hqzbz8UjdXbtwhMtPBZmL
5siaszLutl/ZKDa4k5ZsATFZ4a3HzV6zMrL27nLfuKd579oMEadbcAVQK0/Xfchn
Jn1oAER47OVdbnMGwIsosIwc0x+Yd7TP/R1WEReu6E5lmbzqXUkkXc/hZaEH34DT
A05ch+GZvi5ixVgA0UI8XvRDDlb8iDHVy6HaecBT5/NRBEWOKqXxOeJQXoqRPOpP
62hdyUMkPtczCXB4J7H50s1zenhL2Uw3kP3rTwIDAQABAoIBAQCJ/DK1X3n4lv/d
URcV8e+tymxPNxoWOnMhizsYuvpqt7TTN37OiiuRfXg6saBa9kGcVRyieDU0gbrt
3lX7YZ/wy8PYLv/B4PUOaZiRAWU6g75pnzM7Q/AKOGemQF/3JhdY9o/c+UYM1wTr
LB6EMLFyjg0eT3k7HKCXtSAkEdD57g61BOcNn9FlXHflEyb4m8XcFBi0FAn5R9Hu
j8IoHBiCJMgMNcMwpvdxRz8syUluDtos3c+gRA+J0ScPecC34UxTkdIbRiuSPcAn
be3JPYeDX0JgLcVAL4JiKlDD7e67wL/Nik1OgqZ8cA/4/D+qN4mnT+/4R7WOyJLu
9kepyseRAoGBAP/XHm4UcmSCgMeSA/lIvFU60jG/Zu1smBboV9OfSFtZjrBgwV7E
KRqg9cs4vSdHp0y/Qn19OqfjcB9QM593a778+k2Xrn3D5a2LHg6DhI/zo30uuUHe
lR8hFphtDIsdG7pammAUgPlbWzwZrQUBJ8MaXaaQc0lmde5+H/oBKPFjAoGBAO4D
Ulc3hEQxmCGN38LnprtGEBfCt+ywJJuFvHbTXAMJwgAEh1xqjTmuaMIYZbYKeROD
hklcvAV14dR+pYbrYetqymSHdmwe+YcV3rj4tz6IKv6eE2KJfYKRLzl1xxYyO1tc
JncgZS8GLVCF8HfRC+c5u93gbv/XZFrM7EewU1glAoGALB7HCqjQCXFQEBqoQMdA
Y1pfgWDGuU8u81RiQQaJDefl6ZjmABfIFuWHPeKtDCcZPO0G5GlCQk3AukW0gV2w
4SDzcYok919fLox9RHd91u1nVmFGZYujH9ku8l5r+VmtvHd/g+5FR7tvgm/THLfU
SZs0Z1Ml7pSS5ewuS4kDrI0CgYAAk9N8UK8qdzBWTIDReTxnUekyFY/arCa6ld16
MFMV0s08sMYfTEbhb/HjHqoIggf/Kx+FSAtQvBN7L395T1LiflTVX5rC8mRKlpv+
uOPA7BWmnn2PjKPYUD/cFNQR0rdgJl4VheeY8JvliR2nPMOZoQM6q5O5XS1qJvsf
xWa+XQKBgDDt8OdRRzDvA7b+u6v+MKURuZqa7l75ThUGVs3rtAz5Om/oXFn6RsYI
6DrsDreeT8kKasstxkslGm+b17GGUD8eBfQ8REEDsu5FYM/h/P7Ut49S3AuE19NH
AIAi7cXz41zQrNHBIj5I/Kmazj2WDdrAeT1kOMSf1aVm/BDK7kz0
-----END RSA PRIVATE KEY-----
KEY
        /*
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7d1QGcOil1ojxXNZpTXW
+gxSwRA1vlZH3IsDiqjtmgNPVCHlubvzT78098+XlBcxzlnVXBTmKTrO1ALF9DoX
6ETEs/8Hqzbz8UjdXbtwhMtPBZmL5siaszLutl/ZKDa4k5ZsATFZ4a3HzV6zMrL2
7nLfuKd579oMEadbcAVQK0/XfchnJn1oAER47OVdbnMGwIsosIwc0x+Yd7TP/R1W
EReu6E5lmbzqXUkkXc/hZaEH34DTA05ch+GZvi5ixVgA0UI8XvRDDlb8iDHVy6Ha
ecBT5/NRBEWOKqXxOeJQXoqRPOpP62hdyUMkPtczCXB4J7H50s1zenhL2Uw3kP3r
TwIDAQAB
-----END PUBLIC KEY-----
         */
        ,
        JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzlVpTEUUZYJhwt/pLar5
2TAPAd2dWYC/51NeLUenonCMYu8NqzvWPc+7SoDIKTS1mT/FsGSGu+zxSgYfcwd9
1SwB8Gct/y6N1r7emVpZ+agkhv23NU4Yv1z0kSp79yq66fO+Mws9TE0IeBualq+9
B5PU1i1tECghcG3AndQfrRsDoM3xJWRyr5ee2OTQuaKmKKuIM0twI0dwXO7ENGL9
JHz4VPyKSZ36YGhv5iNBb4pIebWBiVhWdIwm/u4n9sIZRK6iGB2Cvmk7JQnKxS6F
MvUDS3xxIOBd6xXtETHUQE1UN3+jIVzBhNlnuG4wIBdRwFF8a6XP80ZsE1os9z7A
3wIDAQAB
-----END PUBLIC KEY-----
KEY
        ,
        JTPay::CFG_JT_MERID => '631310060050017',
        JTPay::CFG_JT_MERNAME => '诺亚方舟（上海）金融信息服务有限公司',
        JTPay::CFG_JT_HOST => '10.198.4.102',
        JTPay::CFG_JT_PORT => 9524,
        JTPay::CFG_TIMEOUT => 5,
        JTPay::CFG_BILL_PATH => '/srv/jtpay',
        JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
        'sn' => [
            IdGenerator::CFG_MAX => 80999999,
            IdGenerator::CFG_PREFIX => 'jtpay:' . date('Ymd'),
            IdGenerator::CFG_EXPIRE => 129600,//1.5天
        ],
    ],
    'jtpayBroker' => [
        'pay_money_min' => 11,//小额打款确认最小额,以分为单位
        'pay_money_max' => 99,//小额打款确认最大额，以分为单位
        JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpgIBAAKCAQEAyIw4OR0oUpohr5kcPG75k0W61yQ+TUCKjrMIFYnFnT83A0Tl
Awqwk+5ACWpJCbfuBUukpFnFsvF/kwzjmQqroAMevnfwXGHvKbAcFUwmlJVC/arJ
HGh8nYZLn/r+vqyJoJrVlrKVhGsLNZcV15d++kVmE7FKSGQ6tx/bt+5lON2yQD+5
tF+eA1P3l/5On2OMebroD30ysQkpMPgQpPcPByPJOqTNlEjFaaPSWh3y+ylz3TtQ
MXaKs71vI4YLmcE1bgMtsYguaptuUJr8FS0BxPTVqYwFIJ/KRJG/QrfWghue3D62
kjW/7t/XcDBrf9VppiA46zftl52Gl4TRC54oAwIDAQABAoIBAQC0vWqOTrDggPiL
ATppXLqg998Dti5QATLemItYnenzZd12nMiojSHGsJoV4iwhDhr9usaPODjspKmN
JbiZXPyAIU+76Ow+1iRtNcKZjx/WGQ9e/mRxrdlhPn85l0OvJGCE1gZY4mnOBYr8
qUWOH4LYm2L7rHR9+ZbRI20pvziKneezqqc/0/divB6bbsQeTgRJqHK8C9TqBFAs
QvFT8znV3Vlwi51Ympj2S7vWRaYg2BFRpMaitx6nPcgE00xgKKWBId7T6DVZniOW
RcwrIfQKNtmR1lBjEFGIAXLWXLvKOcjdjeRB0GdC2/3snrbcZt1XaRg2upLamRUT
6zi4nR8BAoGBAP59ZdPj2HLtQIJRMMDUsD8cTN6ZWCNmh53wlcZuCghv5uh4Jl6+
ScxMbf/dshrQea9WIxTE42E+Hh1jNAogLHHAExzOu3cCZ7QLbxkU0XzJ1uGExbDQ
ZaLX+2MdmP3McBabhnD7rJm5iYLcvXfYQdNBB+vrk/DPLjDyTp91W8/TAoGBAMm8
4IIC5U/zWhVwWqU1qUUmCNak7TICYNYuGNw7jXA9DblYIEROl+E4PF3MaIgBo91z
ei+IdnIb731KcrupIeYRj0FwhHwJbBXcRpwoahYTGVw7l0RJtJGhR3+VOWXNvpb1
IqUDSeYU3jcih5Ffz4gd2JsV9W4uFS7SvNkvh1kRAoGBAMkhqlzw8pzCTf2w1WtR
rYnzf/1eDH7OBdkZ0AXn6h4I8uJAM3MlyYWh0j4qpRz0L3gYB9neUicExSBMy1BF
ZVrxhyl5akgAqp1te/zCq16I1z+dg/Deg7VUJeaL+eJ8tQnpGTQqdJt6O+glNcmG
LWAdQXl/0oi79bHRj7oPMuTpAoGBAJF6HvwiUnLhLikfqH5SwAoZb2456MKTbHmH
LG5Ek65ImMj7f+lCM8w53W5WpVrOs/hR+d6lLaUD+CQFt88UHFnod8Hc/ezkbokl
G9YoXrgkdblJT7/y1r/d6c1bMtTzFWmOxLjyMiw1CDoCMHjo+qNRwo2zvBUELkph
tcV4vMXBAoGBANuCLkwJh3FQ2EWU6iJ1cA0xviPVA8RB7Yi2s9SQAEzgt1iQDaxg
3mp0qZkUy1iA8mYiCkHMVAbPmC3ADp3AqVMT3YQX8SHXCdNfEzd8XupfB2f+6oh0
c8V9zCxyL1sIQiok0TutZpE5GrYWTaq5DqaG/Hqh60GpxA5GyASR2Ilv
-----END RSA PRIVATE KEY-----
KEY
        /*
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyIw4OR0oUpohr5kcPG75
k0W61yQ+TUCKjrMIFYnFnT83A0TlAwqwk+5ACWpJCbfuBUukpFnFsvF/kwzjmQqr
oAMevnfwXGHvKbAcFUwmlJVC/arJHGh8nYZLn/r+vqyJoJrVlrKVhGsLNZcV15d+
+kVmE7FKSGQ6tx/bt+5lON2yQD+5tF+eA1P3l/5On2OMebroD30ysQkpMPgQpPcP
ByPJOqTNlEjFaaPSWh3y+ylz3TtQMXaKs71vI4YLmcE1bgMtsYguaptuUJr8FS0B
xPTVqYwFIJ/KRJG/QrfWghue3D62kjW/7t/XcDBrf9VppiA46zftl52Gl4TRC54o
AwIDAQAB
-----END PUBLIC KEY-----
         */
        ,
        JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzlVpTEUUZYJhwt/pLar5
2TAPAd2dWYC/51NeLUenonCMYu8NqzvWPc+7SoDIKTS1mT/FsGSGu+zxSgYfcwd9
1SwB8Gct/y6N1r7emVpZ+agkhv23NU4Yv1z0kSp79yq66fO+Mws9TE0IeBualq+9
B5PU1i1tECghcG3AndQfrRsDoM3xJWRyr5ee2OTQuaKmKKuIM0twI0dwXO7ENGL9
JHz4VPyKSZ36YGhv5iNBb4pIebWBiVhWdIwm/u4n9sIZRK6iGB2Cvmk7JQnKxS6F
MvUDS3xxIOBd6xXtETHUQE1UN3+jIVzBhNlnuG4wIBdRwFF8a6XP80ZsE1os9z7A
3wIDAQAB
-----END PUBLIC KEY-----
KEY
        ,
        JTPay::CFG_JT_MERID => '631310060050036',
        JTPay::CFG_JT_MERNAME => '诺亚方舟（上海）金融信息服务有限公司',
        JTPay::CFG_JT_HOST => '10.198.4.102',
        JTPay::CFG_JT_PORT => 9521,
        JTPay::CFG_TIMEOUT => 5,
        JTPay::CFG_BILL_PATH => '/srv/jtpay',
        JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
        'sn' => [
            IdGenerator::CFG_MAX => 80999999,
            IdGenerator::CFG_PREFIX => 'jtpay:' . date('Ymd'),
            IdGenerator::CFG_EXPIRE => 129600,//1.5天
        ],
    ],
    'jtauth' => [
        JTAuth::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEAy+//x2Fehwq6WRX96Xu4TpG3atDFjlNhhBBh1NTJWZMFAXGf
jnkCvWu7SMqsgwJV7rM/9F1Uy8xu24cBydI2SvZ0PeZ8l+XhoNpqoiLUD0DHYfdI
thfCarQZVNXVwKTpwW5VEttozSi5Bbu0RbLoezvQfM7fNMlQNZfxf++/RNFejXa5
1vFtT+DupZHJkYrha2VwZ1+Ppu25aZNJBv94oxZtTUo8AzZ5EA9xE0KQFZjbsqHs
H7uxfDaiKw5NIyzKZr5KUToLI3M9iOBvkJIMK8cwn74ocrkT1+nbGG9TwP+QlV7u
cl+W88X0F7fhWvArpH6LOe5KBO70eZTfreE7TQIDAQABAoIBAQDKvIEbNWnid8C/
FUTBWtPjj6q2TmtGzQ9RWXPYP90W5jgAsnL7EMOviSy69XjAGI9S5/F5PVsx6r5+
EF2vxAFjTlRKwRo1azt9TATbwCHuM+jCNDGdjEsjBn10P8vqYkdbmxKJ14L9CTG+
SFazP2MsN09Q89sjP8o0LSPQmocbofx4ZubKpdLdZtI2F7/nFnNCHxjYbwelZnGq
LK/LNvJ3r8RTesPhOylWdW6W2NKsOwAAxsWj/g8mIMzmGojmBPDosYKErdwwJ8cp
iTF5p6AxowpiGLuDhSZTzkNFpOyUDCFOqi6QVNCzX7NBkdHhCvpLhUCqU2emVmqc
RkWgdqRhAoGBAPZOCWo0NdPiueoHGkkfB2i1JhqL/h88qDzwq5qGzKAkkEsMaehH
1xBx2Yn1hii4Pjd5oveujE1MN0qWS07Y32UJ6MTSsTHZqjbU1B86ebWfHZsxNxGj
I01AN6aoAl4Y1BPh1MzgZtyPU5TCUuQY3RynhufGTx/k7L13yVohB41FAoGBANP3
CRGwBPdAB3iP66omZKP/xo9BK6VvlGEODaKcaoqStD+XwOQYfGamocxVLV68Ussv
0WB65k0gIIZ1W1RjOwvWkCv8vEO+3yWnR8G4xKHQl4I6gr6qxb/kql6T5BmcROGJ
ZEFhTCXQz/Fs1SmBwfm1d4+mQ0DsjcPuCe2AcsJpAoGBAMFdtIB/ar7lIaX8W4OK
a6ulg7uVqjTlzwLAw0g2idEzw2BX55FnTQ1pBCsN6XxwYM/2m52tmBJbQpE4+vh0
xLUzGV3kNx52zu3rGnlF1CVlPL4I3j3ngKB2SPp6rhknjt/pDMKnbbm8gBaqlJ7k
cjq7vuqZQqc8dyusLhSnF6GtAoGAcUfYN/S7Yqx8kalRCHlGVgNvScZJnju4r/oD
vYEcy3xGCqp+syiG65FobTykZ7n8AY1Ht+lWxadC2rlDmyEBQH1mRavnrckHlycE
iXrG07gYEMhWcbHwx3JcvvkI8cr7YRG9W9e1C4zCZUOF1I39bgfWoxX3YW5LAYhp
E94O9ukCgYA5w3+y/gBz71dcRaO12t8re6GCBT2r5BF1wy5RKVZRhpjMKK1KtRlZ
wruuGn/tePRP1BvMXXMVpbDvT3EZ1Z/d8jJl104exmdkCkLcVt7SdDrAJdJKZl3H
RWBZkKkoEETAD+eJlJuPrcz6koy4kgAfxYZVnGAW/7MwAdECM3sUMQ==
-----END RSA PRIVATE KEY-----
KEY
        /*
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAy+//x2Fehwq6WRX96Xu4
TpG3atDFjlNhhBBh1NTJWZMFAXGfjnkCvWu7SMqsgwJV7rM/9F1Uy8xu24cBydI2
SvZ0PeZ8l+XhoNpqoiLUD0DHYfdIthfCarQZVNXVwKTpwW5VEttozSi5Bbu0RbLo
ezvQfM7fNMlQNZfxf++/RNFejXa51vFtT+DupZHJkYrha2VwZ1+Ppu25aZNJBv94
oxZtTUo8AzZ5EA9xE0KQFZjbsqHsH7uxfDaiKw5NIyzKZr5KUToLI3M9iOBvkJIM
K8cwn74ocrkT1+nbGG9TwP+QlV7ucl+W88X0F7fhWvArpH6LOe5KBO70eZTfreE7
TQIDAQAB
-----END PUBLIC KEY-----
         */
        ,
        JTAuth::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA8YYN69ooPfA8sahOj6px
que4Al18dhg+Oj9worMi5ZZsUtUW4SYXONk1dQqEow16+54p+gAL7d5WOWOhFJXh
3qkq0KxNhFQy9vcjDPHT/Jo6BNjd+PWGKT3Ti9/deOmILP0zYEllbbm6cQ4Y5T5O
7u6K5cXyDqP8nG+purRq1g8o9jjw504TyrZ87KRSkYkb5oi3v98c5jR3WGWbtL1i
Dq4uHImhIZWmz7QUByXbzUQssTfvPdSakFFSQLAVTdxiEwpBe4eq1IdFBUn0ysfp
MiAGMoqecSvTBbVSq6g+ToC0OOuNIZqvvRtv+Z+L+A0mtdhIal2bUjF4yCcdjRyQ
KwIDAQAB
-----END PUBLIC KEY-----
KEY
        ,
        JTAuth::CFG_JT_JGID => '666601003',
        JTAuth::CFG_JT_MERID => '530000000000009',
        JTAuth::CFG_JT_HOST => '10.198.4.118',
        JTAuth::CFG_JT_PORT => 9204,
        JTAuth::CFG_TIMEOUT => 10,
    ],
    //钱礼俊 cloudcc(crm的替代品)
    'cloudcc'=>[
    'cloudcc_interface_url'=>'http://10.3.11.122:9080/noahwmcrm/distributor.action',
    'sys_name'=>'cloudcc_crm',
    'user_name'=>'crm_api@noahwm.com',
    'password'=>'',
    'pwd'=>'tSWBUV1UkApFDT1HUJbBjOMuPzmrGQT695EuEKqZpOI=',
     ],
   
    'jtquery' => [
        'pay_money_min' => 11,//小额打款确认最小额，以分为单位
        'pay_money_max' => 99,//小额打款确认最大额，以分为单位
        JTPay::CFG_JT_ACCNO => '695413381',
        JTPay::CFG_QUERYACCBALANCE_URL => 'https://10.198.4.16:10085/BankBusinessService/ws/blinkMer/queryAccBalance',
        JTPay::CFG_QUERYACCTRANSDETAIL_URL => 'https://10.198.4.16:10085/BankBusinessService/ws/blinkMer/queryAccTransDetail',
        JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEAnoRqPheUKMAz20JeCwkBcPV+0zrAX3V+WlmNJeo46F99vP4u
Ixtq73qbrvrU7cVVJflNuucOGUd5t80hIRCSrrNDyNFtKMy3F7oV3oLUWrevDUAn
qCjj3RXXBtmDk/qxVdKMfls4NkFv4ItpOQxMDerqZZp3kDLKFvno51RKRy1T0+Y0
CNsXTMyGdsIz7QlOqyHVj14O6GFHMm7SilYmchDjO6eBvzaVDYqgYfFROrbPRXpO
BmT9ldXQq+USaTSUdP5gjUEfmEYzJ0q+OEbSWZc6wgfxesitxPCnPOM20Lk+Ttop
psB03BDFC3q5rLhfsOzNlGoXwcdQFDbMLIiMRwIDAQABAoIBADDInY24Ye9cn1jm
Bt0si1YBJ2PIW/XEyfryPl8hwxu4b5DfRMGnKXTD7e+e4DLAnSDPpZ1UiGE9PvdS
2NQ9Lnc3UjAWS5rXza0uppZQ+xtkFipkyQ+WbfHXS9Ke1ECRUUwRPQ2R8y23W7/m
B5736twJpNNaA1vMVadWh9fRd/6JN42Zi3BeZSQGnIfBs1oJ9K3RYbgDHQUUYVhr
hDQnKKDQgvYYRz1X0bVSPezfUh/plxxhIkLMfyIHFhapryNPVhbXq6ykLpTvGb7B
VbMZxZFN0/vgijNkWkMbo3Pz6N9ogTE/72SBjcxGtv9drrq+s7R+tD49s98InhIS
V+ZZSfkCgYEAzzjPN7ClUIWR9k5yuOCH/E7ACpw2sXZzLqZ3H7OlgB23l9yr3Om5
5EJ9Wy3hAOJOodH6f8iBHgv2wKGswWKfrAGVmoboT6bHHsmyGKQ+hPGLqBKSZfhq
2PCeeYx/w22fzwmiQ1/WpSHx44O8HW/BvB3VyelgAa8Yl8YDxILnTFMCgYEAw9Sp
sCAvty+q9ohQwuFiTeIZbLOAdHrcVVW4dJW8lWxPmZn2kAKLqtnnKd/bX1hfWxT8
ZvY0XxgQvZdNgNOggQ2uEcIpzuasbA/Gqjfgikrly7R3VWnjTMudc7hXnFEyooOd
QXGCx9JU9hdq9sHjm1jgMptJ0+i2zcxY58uHob0CgYBApFwf5z7qq4Ao8bff7Er/
biGCLdDx8x1jRBKNFSFfoeWPvgru0wpmJkeslddGy1H0MOiPzCBbGyhSVxzpBrcA
lU3x8nutvT0IYaro/PNzzVXfjEuW+7N5ETaefDGu6RedIkg39EGlKb2nV4TrOd2Z
rUTvw5lrbQ+i6OZr+tnkeQKBgQCpg7rnZNUpAzBAe7s9FpBbzq4ndDJrobZ8f9lN
whgeWEWHNslB25I+8KSzkL16iSrx0vaxwcmPz2seUoyaSZaUX90gLiy2luMGH5ne
2sOZsj+815i87Q3++fpvo1DjVT45gyhq7/E/O4ikBZ1nwGpfnM1lwRplPvqOpqcG
7x2XGQKBgQCQig1m7mdnew2TpDGZ27dwCBaMCK3y+3YyorxxbSknvh9V7/uiuVz+
aqGENeVXrFT5mJnAbbHHpTj06Wdrpb5aMOZ4yE/dfKLM+/CGVogqE62qVOd9mRq/
kM/qnZNDJcXS+1QrL3r7FU7xU8IOEKaQBEdGNmY+E29Qed7B3ZXrOg==
-----END RSA PRIVATE KEY-----
KEY
        ,
        JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwDc8G1lLKS0So0WOS9te
wyvIBCM/xAJAzJKpgwfkUwl+8dIRGhQ7P22MppUJBsbKMGcCtCfctgpjLvWK9L8V
FTBZUx8gLREHWwtBLVY310L25kMMsT2N0ZiUdX1PcPmkIW6WpbrT0o3FJ8cYmx/x
TGfU4dw0iM1iErOqJ7FWjaekj24YHU/x9TKEpg70kvQz5Nbyd6C1VNyEt6aWqMG5
RQ29LmEjPDGflLB5hsLqjl3Pa61N5z136+JNeGH3S/zWu+zjDoiWlEFtbev8Atvr
jTY0yXaWTUBMqU/2y9JhCNojQjCdJYEmn3XqGDEADQVUalY7n3keHffGflXZXpDZ
PQIDAQAB
-----END PUBLIC KEY-----
KEY
        ,
        JTPay::CFG_JT_MERID => '560000000000000',
        JTPay::CFG_JT_MERNAME => '正行IFA平台',
        JTPay::CFG_JT_HOST => '10.198.4.16',
        JTPay::CFG_JT_PORT => 10085,
        JTPay::CFG_TIMEOUT => 5,
        JTPay::CFG_BILL_PATH => '/srv/jtpay',
        JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
        'sn' => [
            IdGenerator::CFG_MAX => 98999999,
            IdGenerator::CFG_PREFIX => 'jtpay:' . date('Ymd'),
            IdGenerator::CFG_EXPIRE => 129600,//1.5天
        ],
    ],
//jtmpos Added by liaotao
    'jtmpos' => [
                'pay_money_min' => 11,//小额打款确认最小额,以分为单位
                'pay_money_max' => 99,//小额打款确认最大额，以分为单位
                JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA42SlLDwVVaVeJ+WO/vhs2Use5PSrjunlG0iQKHMdcoTd7swN
JUK0NxQql9N14J0HgML6boRWh14aOa0Uqio+dtk2dAtKVbLxD7qVIj1qPNcf5wmC
4VGtokojA+ZRBbgN0VOSCCe6XwaIGoe/zcw7qEVICnTImZLHIk/No6hlzoz3u8Xl
63Pg/tekA6j9sflxk/AK64guhE3FU+LwYQ5cifi0USruXoXOcmceBXvuwgoOv65r
lVGJRpuvhq0vx+HhZRcyfz8OJp4aR1B5XiUvAVk+2G0Rbux4QcZOgYsigiES7iyM
esyTzM2W6qsfzsTAtLAQ1p6W2kRqE+9pKNO1vwIDAQABAoIBAAVxpmattZEMWXm5
DDhceDanjsDKfsT4Io0JqrHdN6pDNhD+f54Rv8DF0dM6s8rB16kkgdxdfLjW7ufM
lf8Q7dfokV4r2wa8Nvs6a1GbiMyWFeRxHNoKG48UGUyBmhT5+BK33nolgVe/D0kb
UOM7bX400mm1rAvJMM1IfdLaOD2+pKkK2OhFTQxEWbhSfMf2gXO0mnZrLylxdOEa
a1y+dZ6HgshWJnNUbJ7bC/tV0maZgaluuk60Ag7uMigC0PlkjRWk2XeMy98mRGd1
iKyx4/johtIowpf/y3R0/Emd5cw2r1ODxo8sDWCDCPMw9kS/ykyqz4IIgIJydGqi
sb3H/vkCgYEA//fyq/Ef2q9XwSv0ArnSGPF88PUGpgvcrg2lEizF619aMKei4KAe
7e/iChtwrc1QLzmOkosWLgHvlDLsH062sSupEXgHkcfWrN5EnNtEvOYpQ3YUTCzP
FA85zzUsb8IxbNW6qLZqIXxh0a2yWLCjiDe2+cuyw98Xz0BVzzHsBFsCgYEA42vM
YcUaijcfn4KqhWt2P6LuGPr4DnyVQpV9QwLfy+LOmJJfn9ugzq35mfhvJsgI9rPo
veKIPo/ZIAZrkf0+XQ/Vt+MdeXExjhZVbN8iQQcJhSS9ezjqFa0C1LJQwww3g8yO
65t+lXcF4erqgfwE/F7FLRhMfX4y08FOz+SsgW0CgYEA3vsdUIG+ESA8XxAuAg3k
I0yDXdjl0NJ2jL1gNmQAillHVSlDr1BtgTM+gzWCRDWeC3WlaK13Rd7z2PM/VMqa
Rd7V6lzYozsmHPOHa+lriO8rtRPw/KbwQfY9ku8sZbMSoU/SylQWQlN7V1BsE+zU
mL6ITDUR5qW6tRXDarp/cw8CgYEAlIANg0IbZGk+QwAlrN1Q55jSdIlcdMkxBbtr
gdhcnlvJn6LkwhO923eK5tlsaxxvjfhIX8WORZvUoa7PixKcKFRwr5Sj6GrbevZm
baL+UQvxUXl+KPovEFxa3txZFCPkFDH8mSh97cc8lhq5aotQDiMsCZg2SjOfqNov
Rl0Br7kCgYBZmtOUE3eLqQvWAOMbaAsnXotY/t5tFqV8t9q6W6N0Nu4FknZVZNNg
HDG6f9RV4Ir7Cc0Rd1OyBXHrHH10rx95NiKXp0x+/Q3Pdpb/PDBrKI2OfXqu0ozI
6Jb9WSblScE8MhcSISknSIA9p0Oqlqgm/BTcB4OBP7FEX+HxV4ipBQ==
-----END RSA PRIVATE KEY-----
KEY
                ,
                JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsu4GwZezzY8NwrlAGIBu
A+wP763B0IZ2d6gXRCf+IBWjajqtQK1GgvHPJlEPJeOCcsT+ZUYdidImKUzFDqcI
E6rrdJ9R+iHkb76jjjcGL5cd6l5IDJXvrY1RhXef3zc0YZSteoYtIjO8/WgotBgG
nqHUivzFS5rY4fTlRr6cgmv85NiiYW2Y2dMMd5LRJdiLGdQQZijop8ojvpesyrwJ
xRPq1GLHaRsmTDSXH438DoWZZ42UZuT3xJyfzKydEF+LAbeIln/qQKZoMwhPCqpl
XrFdWTfLD5kvNQgUWplCF2fr/P/ddgbblS/CQGQeSZho7C7yhVqWtfswnc4SdNw3
9QIDAQAB
-----END PUBLIC KEY-----
KEY
                ,
                JTPay::CFG_JT_MERID => 'A00000004      ',
                JTPay::CFG_JT_INSTITUTION_ID => 'A00000004000001',
                JTPay::CFG_JT_MERNAME => '正行IFA平台',
                JTPay::CFG_JT_HOST => '10.198.40.101',
                JTPay::CFG_JT_PORT => 9201,
                JTPay::CFG_TIMEOUT => 5,
                JTPay::CFG_BILL_PATH => '/srv/jtpay',
                JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
                JTPay::CFG_MPOS_PRODUCT_CODE => '00000870',
                'sn' => [
                    IdGenerator::CFG_MAX => 98999999,
                    IdGenerator::CFG_PREFIX => 'jtmpos:' . date('Ymd'),
                    IdGenerator::CFG_EXPIRE => 129600,//1.5天
                ],
            ],
            'jtmposBroker' => [
                'pay_money_min' => 11,//小额打款确认最小额,以分为单位
                'pay_money_max' => 99,//小额打款确认最大额，以分为单位
                JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA42SlLDwVVaVeJ+WO/vhs2Use5PSrjunlG0iQKHMdcoTd7swN
JUK0NxQql9N14J0HgML6boRWh14aOa0Uqio+dtk2dAtKVbLxD7qVIj1qPNcf5wmC
4VGtokojA+ZRBbgN0VOSCCe6XwaIGoe/zcw7qEVICnTImZLHIk/No6hlzoz3u8Xl
63Pg/tekA6j9sflxk/AK64guhE3FU+LwYQ5cifi0USruXoXOcmceBXvuwgoOv65r
lVGJRpuvhq0vx+HhZRcyfz8OJp4aR1B5XiUvAVk+2G0Rbux4QcZOgYsigiES7iyM
esyTzM2W6qsfzsTAtLAQ1p6W2kRqE+9pKNO1vwIDAQABAoIBAAVxpmattZEMWXm5
DDhceDanjsDKfsT4Io0JqrHdN6pDNhD+f54Rv8DF0dM6s8rB16kkgdxdfLjW7ufM
lf8Q7dfokV4r2wa8Nvs6a1GbiMyWFeRxHNoKG48UGUyBmhT5+BK33nolgVe/D0kb
UOM7bX400mm1rAvJMM1IfdLaOD2+pKkK2OhFTQxEWbhSfMf2gXO0mnZrLylxdOEa
a1y+dZ6HgshWJnNUbJ7bC/tV0maZgaluuk60Ag7uMigC0PlkjRWk2XeMy98mRGd1
iKyx4/johtIowpf/y3R0/Emd5cw2r1ODxo8sDWCDCPMw9kS/ykyqz4IIgIJydGqi
sb3H/vkCgYEA//fyq/Ef2q9XwSv0ArnSGPF88PUGpgvcrg2lEizF619aMKei4KAe
7e/iChtwrc1QLzmOkosWLgHvlDLsH062sSupEXgHkcfWrN5EnNtEvOYpQ3YUTCzP
FA85zzUsb8IxbNW6qLZqIXxh0a2yWLCjiDe2+cuyw98Xz0BVzzHsBFsCgYEA42vM
YcUaijcfn4KqhWt2P6LuGPr4DnyVQpV9QwLfy+LOmJJfn9ugzq35mfhvJsgI9rPo
veKIPo/ZIAZrkf0+XQ/Vt+MdeXExjhZVbN8iQQcJhSS9ezjqFa0C1LJQwww3g8yO
65t+lXcF4erqgfwE/F7FLRhMfX4y08FOz+SsgW0CgYEA3vsdUIG+ESA8XxAuAg3k
I0yDXdjl0NJ2jL1gNmQAillHVSlDr1BtgTM+gzWCRDWeC3WlaK13Rd7z2PM/VMqa
Rd7V6lzYozsmHPOHa+lriO8rtRPw/KbwQfY9ku8sZbMSoU/SylQWQlN7V1BsE+zU
mL6ITDUR5qW6tRXDarp/cw8CgYEAlIANg0IbZGk+QwAlrN1Q55jSdIlcdMkxBbtr
gdhcnlvJn6LkwhO923eK5tlsaxxvjfhIX8WORZvUoa7PixKcKFRwr5Sj6GrbevZm
baL+UQvxUXl+KPovEFxa3txZFCPkFDH8mSh97cc8lhq5aotQDiMsCZg2SjOfqNov
Rl0Br7kCgYBZmtOUE3eLqQvWAOMbaAsnXotY/t5tFqV8t9q6W6N0Nu4FknZVZNNg
HDG6f9RV4Ir7Cc0Rd1OyBXHrHH10rx95NiKXp0x+/Q3Pdpb/PDBrKI2OfXqu0ozI
6Jb9WSblScE8MhcSISknSIA9p0Oqlqgm/BTcB4OBP7FEX+HxV4ipBQ==
-----END RSA PRIVATE KEY-----
KEY
                ,
                JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsu4GwZezzY8NwrlAGIBu
A+wP763B0IZ2d6gXRCf+IBWjajqtQK1GgvHPJlEPJeOCcsT+ZUYdidImKUzFDqcI
E6rrdJ9R+iHkb76jjjcGL5cd6l5IDJXvrY1RhXef3zc0YZSteoYtIjO8/WgotBgG
nqHUivzFS5rY4fTlRr6cgmv85NiiYW2Y2dMMd5LRJdiLGdQQZijop8ojvpesyrwJ
xRPq1GLHaRsmTDSXH438DoWZZ42UZuT3xJyfzKydEF+LAbeIln/qQKZoMwhPCqpl
XrFdWTfLD5kvNQgUWplCF2fr/P/ddgbblS/CQGQeSZho7C7yhVqWtfswnc4SdNw3
9QIDAQAB
-----END PUBLIC KEY-----
KEY
                ,
                JTPay::CFG_JT_MERID => 'A00000004      ',
                JTPay::CFG_JT_INSTITUTION_ID => 'A00000004000001',
                JTPay::CFG_JT_MERNAME => '正行IFA平台',
                JTPay::CFG_JT_HOST => '10.198.40.101',
                JTPay::CFG_JT_PORT => 9201,
                JTPay::CFG_TIMEOUT => 5,
                JTPay::CFG_BILL_PATH => '/srv/jtpay',
                JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
                JTPay::CFG_MPOS_PRODUCT_CODE => '00000870',
                'sn' => [
                    IdGenerator::CFG_MAX => 98999999,
                    IdGenerator::CFG_PREFIX => 'jtmpos:' . date('Ymd'),
                    IdGenerator::CFG_EXPIRE => 129600,//1.5天
                ],
            ],
    'erp_order' => [
        'wsdl' => 'http://10.3.11.17:6868/InFactor/O2OUpsertOpportunityWS.asmx?wsdl',
    ],
    'hs' => [
        'baseUrl' => [
            'http://10.3.2.20/fundapi/restful',
            'http://10.3.2.20/fundapi/restful',
        ][mt_rand(0, 1)],
        'md5Key' => '88888888',
        'merid' => '8888',
         'isSupportAllDay' => true,
    ],
    'erp_sql_server' => [
        'host' => 'erp',
        'username' => '75cPknlV4tke+weC2yY8eQ==',
        'password' => 'pUgpoo8lJ6snqbSpUshlJw==',
        'db' => 'ERP',
        'encrypt' => true
    ],
    'session_expire' => 3600000,
    'phonecode_expire' => 900000,
    'yht_oracle' => [
        'username' => 'YLxFqNjf1OOwgUp33v433Q==',
        'password' => 'pUgpoo8lJ6snqbSpUshlJw==',
        'db' => 'DMTQPTN5gEps1nuwBbv25Gc3Gox87qvLEMncPZcPk+xIsp9TPAyv5J3jMNJK0XRicDrHQ81W/Lh/DS+vxT7MMbIxRmFF+4m9sv0cxBoFUVHIAVXem4oCEO5bcaY8ozIsp39B01q0c0m6yntcZhZir6dFdooAJGef0rZF3wknSALiaMEff5OduU01xGXQAqfwphy/gObiXe7rJlC6a6vw9w==',
        'tableSchema' => 'oap_prod',
        'encrypt' => true
    ],
    'jituan_oracle' => [
        'db' => '(DESCRIPTION =(ADDRESS_LIST =(ADDRESS = (PROTOCOL = TCP)(HOST = 10.3.2.86)(PORT = 1521)))(CONNECT_DATA =(SERVICE_NAME = orcl)))',
        'username' => 'uomp',
        'password' => 'uomp',
        'encrypt' => true
    ],
    'yht' => [
        'baseUrl' => 'http://ci.noahwm.com.local/rest/',
        'subscriberNo' => 'O2O',
        'ifaNBFaCode' => '0209',
        'ifaNBFaName' => '中后台分公司',
        'ifaWBFaCode' => '0210',
        'ifaWBFaName' => '外部分公司',
    ],
    'session_online' => [
        'app' => 1,
        'h5' => 2,
        'pc' => 2,
    ],

    'noahAes' => [
        'kms' => 'http://kms.noahwm.com.local/kms/dorado/webservice/KeyService.wsdl',
        'o2o_system' => 'o2osys_prod',
        'yht' => 'o2o_prod'
    ],
    'idInData' => [
        'url' => 'http://121.40.136.150:8080/IdInDataAu/api/authenInfoApi.htm',
        'userId' => '100219',
        'md5Key' => 'I3f15155r1U9p9L1NFCHi35335E71N11',
        'desKey' => 'I17IPa11SBVs1797971575559ZO9753m',
    ],
    'jpush' => [
        'fa' => [
            'inHouse' => [
                'apiURL' => 'https://api.jpush.cn/v3/push',
                'appKey' => 'b5ec9e75acb10396733e5a15',
                'masterSecret' => '75dabd6750c79fad54665552'
            ],
            'appStore' => [
                'apiURL' => 'https://api.jpush.cn/v3/push',
                'appKey' => 'c9b533d605f848df11d0db86',
                'masterSecret' => '760ea2a682bfd9ada01eb0ca'
            ]
        ],
        'user' => [
            'inHouse' => [
                'apiURL' => 'https://api.jpush.cn/v3/push',
                'appKey' => '248bff9d95c2a24adc454731',
                'masterSecret' => '568527411e9895507e4980a1'
            ],
            'appStore' => [
                'apiURL' => 'https://api.jpush.cn/v3/push',
                'appKey' => '7ab3124cdd2564cb530c5cf7',
                'masterSecret' => '0643d7fa64219d337667c14e'
            ]
        ]

    ],
    'company_config' => [
        'img_expire' => 900,
        'company_url' => 'http://jg.ifaclub.com'
    ],

    // webcookies安全验证, //李兵,郭士魁
    'web_cookie' => [
        'isEnableSecure' => true,
        'isCheckDomain' => true,
        'default_cookie_expire' => 3600,
        '.jg.ifaclub.com' => [
            'cookie_expire' => 3600,
            'path' => '/',
        ],
        '.my.ifaclub.com' => [
            'cookie_expire' => 3600,
            'path' => '/',
        ],
        '.m.ifaclub.com' => [
            'cookie_expire' => 3600,
            'path' => '/',
        ],
        '.static.ifaclub.com' => [
            'cookie_expire' => 3600,
            'path' => '/',
        ],
        '.fs.ifaclub.com' => [
            'cookie_expire' => 3600,
            'path' => '/',
        ],
        '.t.ifaclub.com' => [
            'cookie_expire' => 3600,
            'path' => '/',
        ],
    ],
    
    'qiniu' => [
        'accessKey' => '_gsUZbrLzcDO-vHRLojw0holcS0oaICOyrkDiMOh',
        'secretKey' => 'gW0e_B6Yne6g4AeYeIIflRsiNqQ0gafMH4CO3nDE',
        'bucket' => [
            QiniuUploader::BUCKET_EDITOR => [ //富文本文件存放空间
                'name' => 'ifa-cms',
                'url' => 'https://dn-ifa-cms.qbox.me'
            ],
            QiniuUploader::BUCKET_CONTRACT => [ //合同文件存放空间
                'name' => 'ifa-contract',
                'url' => 'https://dn-ifa-contract.qbox.me',
                'allow' => [
                    '.pdf'
                ]
            ],
            QiniuUploader::BUCKET_VERSION => [ //版本发布文件存放空间
                'name' => 'ifa-apk',
                'url' => 'https://dn-ifa-apk.qbox.me'
            ],
            QiniuUploader::BUCKET_AVATAR => [
                'name' => 'ifa-avatar',
                'url' => 'https://dn-ifa-avatar.qbox.me'
            ],
            QiniuUploader::BUCKET_COMPANY_DATA => [
                'name' => 'ifa-company-data',
                'url' => 'https://dn-ifa-company-data.qbox.me'
            ],
            QiniuUploader::BUCKET_COMPANY_VIDEO => [
			    'name' => ' ifa-video',
			    'url' => 'https://o1hmw2dii.qnssl.com'
			],
        ]
    ],
    'h5Url' => 'https://m.ifaclub.com',
    'h5TrainUrl' => 'http://t.ifaclub.com/cpk/', //方舟学院 郭士魁
    'h5StaticUrl' => 'https://static.ifaclub.com/',  //pengying
    //注释1.6版本配置 
	'achievementUrl' => 'https://static.ifaclub.com/appview/achievement/index.html', //王福星
	'functioinIconsIfa' => [
	    'product' => [
	        'title' => '产品预告',
	        'icon' => 'https://dn-ifa-static.qbox.me/754148152569c53d0c94c35.63354976',
	        'target' => ''
	    ],
	    'namecard' => [
	        'title' => '我的名片',
	        'icon' => 'https://dn-ifa-static.qbox.me/1285595461569c53bed94073.70288863',
	        'target' => 'ifapro://mycard'
	    ],
	    'course' => [
	        'title' => '方舟学院',
	        'icon' => 'https://dn-ifa-static.qbox.me/767067885569c53713c61e3.12732002',
	        'target' => ''
	    ],
	    'qrcode' => [
	        'title' => '我的二维码',
	        'icon' => 'https://dn-ifa-static.qbox.me/1323286362569c53a4c2d407.27651273',
	        'target' => 'ifapro://qr'
	    ],
	],
    'riskTestUrl' => 'https://static.ifaclub.com/appview/riskevaluation/index.html',//风险测评
    'accreditedInvestorUrl' => 'https://static.ifaclub.com/appview/qualifiedconfirm/index.html',//投资者认定    
    'joinCompanyUrl' => 'https://static.ifaclub.com/jgfaregister/index.html',
    'msgcenterOld' => 'https://static.ifaclub.com/msgcenter/',//1.5.0（包括1.5）版本之前的消息中心地址  @唐誉
    'msgcenter' => 'https://static.ifaclub.com/msgcenter_new/',//1.6.0版本消息中心地址  @唐誉
    'gwUrl' => 'https://api.ifaclub.com',
    'hkmRegUrl' => 'http://t.cn/RUSOA1p',
    'courewarepreview'=>'https://static.ifaclub.com/ifaClass/detail.html?coursewareid=', //方舟课堂预览 钱礼骏
    'FinanceProductBenefitRateUrl'=>'https://static.ifaclub.com',//H5业绩比较基准  彭斌
    'courewarePwd' => 'ifaclub',//优酷视频的密码 --郭士魁
    'jtpay_notification' => [ //金通对账 手机提醒
        'cwq7411' => 18616733373,
    ],
    'bankIcon' => 'https://dn-ifa-static.qbox.me/images/bank/',
    //强制更新的配置(1.3.0版本及以下强制升级)
    'forceUpdateVersionSetting' => [
        'android' => [
            'user' => [
                'com.noah.ifa.app.standard' => 72,
            ],
            'ifa' => [
                'com.noah.ifa.app.pro' => 72,
            ]
        ],
        'ios' => [
            'user' => [
                'com.ifa.app.inHouse.std' => 1507315,
                'com.ifa.app.std' => 1512052,
            ],
            'ifa' => [
                'com.ifa.app.inHouse.pro' => 1507177,
                'com.ifa.app.pro' => 1511026,
            ]
        ],

        'isEnabled' => true,

    ],

    //可信反代whitelist
    'trustedProxies' => [
        '10.3.210.33', //新dmz_proxy
        '10.3.210.23', //旧dmz_proxy
        '127.0.0.1',
    ],


    //java系统接口配置
    'javaSystem' => [
        'url' => 'http://backend.ifaclub.com/settle/gateway',
        'javaCashUrl' => 'http://backend.ifaclub.com/app/gateway',// 目前现金宝 added by pengying
        'enable_white_list' => true,
        'ip_white_list' => [
            '10.3.6.31',
            '10.3.6.32',
            '10.3.6.36',
            '10.3.6.37',
            '10.3.6.38',
            '10.3.6.39',
            '10.3.6.40',
            '10.3.6.41',
            '10.3.210.33', //新dmz_proxy
            '10.3.210.23', //旧dmz_proxy
        ],
        // 找java同学配置,书伟
        'insuranceUrl' => 'http://backend.ifaclub.com/order/gateway',
        'stockUrl' => 'http://backend.ifaclub.com/order/gateway',//如果你迷惑为啥这两个路径配置为啥一样？sit环境是不一样的，生产环境搞成同一个路径了
        'productSearchUrl' => 'http://backend.ifaclub.com/search/gateway',
        'productUploadUrl' => 'http://backend.ifaclub.com/search-master/gateway',
        'faMessageUrl' => 'http://backend.ifaclub.com/message/gateway', //消息中心的url
        'javaCashUrl' => 'http://backend.ifaclub.com/app/gateway',// 目前现金宝
        'contractBuildPdfUrl' => 'http://backend.ifaclub.com/econtract/gateway', //         
    ],

    'hr_sql_server' => [
        'host' => '10.2.2.2',
        'username' => 'hr_o2o',//hr_o2o
        'password' => 'hr_o2o',
        'db' => 'NOAHHR',
        'encrypt' => false
    ],

    'editor_mobiles' => [
        '18601771621',
        '18616803002',
        '18616910645',
        '15801816961',
        '15618273535',
        '13917868488',
        '15077822104',
        '18621378781',
        '13167058682',
    ],

    'upkeep_mobiles' => [//产品存续人员(批次错误通知)
        '18601771621',//陈亮
        '18616910645',// 刘星
        '18616803002',// 涨潮
        '15077822104',// 贾秀青
        '15618273535',// 范磊
        '13167058682',// 王君
    ],

    'insurance_intro_url' => [
        'U2001' => 'https://static.ifaclub.com/nocache/usernotice1.html',
        'U2005' => 'https://static.ifaclub.com/nocache/usernotice3.html'
    ],
    //是否启用新联行号流程开关
    'isEnabledBranchBank' => true,   
    'isEnabledCloudCC'=> true, // 钱礼骏 
    //天保盈产品代码 -- 王福星
    'insurance_tianbao' => [
                '10404002'
    ],

    //ftp config
    'sftp' => [
        'host' => 'worker.ifaclub.com',
        'username' => 'filetran',
        'password' => 'filetran@noahwm',
    ],

    //前海人寿产品代码
    'insurance_qianhai' => [
        'U2001',
        'U2005'
    ],
    'insurance_qianhai_notice' => '• 本人同意身故保险金受益人为法定受益人$$• 本人承诺所填写各项信息均真实完整，知晓并同意贵公司采集本人信息为本人提供计算保费、核保、发送保险合同信息等服务之用。如因信息不完整或不真实而导致本人权益受损，贵公司无需承担责任。如果本人信息发生变更，将及时至贵公司办理更正手续。贵公司承诺未经本人同意或授权，不会将本人的信息用于贵公司和第三方的销售活动。$$• 本人已阅读保险产品的条款，了解条款中保险责任、责任免除、犹豫期及退保费用等内容，本人愿意根据全部条款的约定投保。$$• 本人已阅读保险条款、产品说明书和投保提示书，了解本产品的特点和保单利益的不确定性。同意将接收电子保单日作为保单合同签收日。同意如发生有关网上投保险种、保险金额等方面的分歧，以贵公司的电子记录凭证等数据电文作为判断本保险合同的唯一合法有效证，该凭证具有完全证据效力。',
];
