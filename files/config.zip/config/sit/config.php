<?php

return [
    'pdo' => [
        'dsn' => 'mysql:host=svr.kingifa.com;dbname=king',
        'username' => 'root',
        'password' => 'king-ifa3',
    ],
    'rabbitmq' => [
        'host' => 'svr.kingifa.com',
        'port' => 5672,
        'username' => 'test',
        'password' => 'test',
        'vhost' => '/',
    ],
    'predis' => ['tcp://svr.kingifa.com', null],
    'mongo' => ['mongodb://svr.kingifa.com:27017/ifa', []],
];

