<?php
use Common\Utility\IdGenerator;
use King\Core\JTPay\JTAuth;
use King\Core\JTPay\JTPay;
use King\Core\Uploader\QiniuUploader;

return [
    'pdo' => [
        'dsn' => 'mysql:host=10.3.33.27:1331;dbname=king',
        'username' => 'ifa-uat',
        'password' => 'hHHgYU0jVrha',
    ],
    'dzh-pdo' => [
        'dsn' => 'mysql:host=10.3.33.27:1331;dbname=caihui_1',
        'username' => 'ifa-uat',
        'password' => 'hHHgYU0jVrha',
    ],
    'rabbitmq' => [
        'host' => 'worker.ifa-uat.cf',
        'port' => 5672,
        'username' => 'king',
        'password' => 'king-ifa3',
        'vhost' => '/',
    ],
    // 'predis' => ['tcp://redis.ifa-uat.cf', null],
    'predis' => [
        [
            'scheme' => 'tcp',
            'host' => 'redis.ifa-uat.cf',
            'port' => 6379,
            'password' => 'iMfffisv4wpygftxkdrlqbmyuSvlqt8',
        ],
        null,
    ],
    'mongo' => [
        'mongodb://10.3.33.25:2331,10.3.33.25:2332',
        [
            'db' => 'king',
            'username' => 'ifa-uat',
            'password' => 'PvLxS7CxYlfx',
            'replicaSet' => 'rs0',
        ]
    ],

] + [
    'voice' => [
        'accountSid' => '8a48b5514d32a2a8014d32cbed750044',//主帐号
        'accountToken' => '630465539a774b7c8f600669276b4344',//主帐号Token
        'appId' => 'aaf98f894d328b13014d32d7cacd00aa',//应用Id
        'serverIP' => 'app.cloopen.com',//请求地址，格式如左，不需要写https://
        'serverPort' => '8883',//请求端口
        'softVersion' => '2013-12-26',//版本号
        'playTimes' => 3,//播放次数
        'displayNum' => '400-829-8358',//显示的主叫号码, 需要提交带有公章的承诺函 扫描件，对方审批通过后才可用，所以此处配置没用，可去除--comment by eaglegends on 2015.07.15
        'respUrl' => '',//语音验证码状态通知回调地址，云通讯平台将向该Url地址发送呼叫结果通知
    ],
    'sms' => [
        'priority' => [
            'mwkj' => 1,
            'ytzy' => 3,
            'ytyd' => 2
        ],
        'provider' => [
            //梦网科技
            'mwkj' => [
                'name' => '梦网科技',
                'apiURL' => 'http://61.130.7.220:8023/MWGate/wmgw.asmx/',
                'userId' => 'J50336',
                'password' => '269376',
                'needBrands' => 0, //是否显示品牌名称(即 短信签名)
            ],
            //移通自有通道
            'ytzy' => [
                'name' => '移通自有通道',
                'apiURL' => 'http://esms.etonenet.com/sms/mt',
                'userId' => '6824',
                'password' => 'ny68fz30',
                'needBrands' => 0,
            ],
            //移通移动通道
            'ytyd' => [
                'name' => '移通移动通道',
                'apiURL' => 'http://esms.etonenet.com/sms/mt',
                'userId' => '6824',
                'password' => 'ny68fz30',
                'needBrands' => 0,
            ]
        ]
    ],
    //彭郢 2016-01-25 亿业邮件服务商添加
    'mail' => [
        'host' => 'smtp.easeye.com.cn',
        'port' => 27,
        'user' => 'lisongtao@noah-fund.com',
        'pwd' => 'yiyesupport@noah-fund.com',
        'from' => 'support@customer.ifaclub.com',
        'fromName' => '财富方舟',
    ],  
    

    /* // uat-a 临时修改
    'mail' => [
               'host' => 'smtp.mailgun.org',
               'port' => 25,
               'user' => 'postmaster@mcfog.wang',
               'pwd' => 'bf7d55113f9bf7b67e660af762b947d4',
               'from' => 'no-reply@mcfog.wang',
               'fromName' => '方舟UAT',
           ],
   */
    'crm' => [
        'crmUrl' => 'http://10.3.33.59:8080/wsproj/services/sFOutboundWSBean?wsdl',
        'obtype1__c' => '理财师分配',
        'obtype2__c' => 'O2O微诺-预约理财师',
        'obstatus__c' => '0',
        'memo__c' => '',
    ],
    //钱礼俊 cloudcc(crm的替代品)
    'cloudcc'=>[
        'cloudcc_interface_url'=>'http://10.3.33.125:9080/newnoahwm/distributor.action',
        'sys_name'=>'cloudcc_crm',
        'user_name'=>'demo@noahwm.com',
        'password'=>'111111',
        'pwd'=>'X8mmHi%2BSZntYuvukTxG0rw==',
    ],

    'jtpay' => [
        'pay_money_min' => 11,//小额打款确认最小额,以分为单位
        'pay_money_max' => 99,//小额打款确认最大额，以分为单位
        JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEAqk6yCd6plsjib2dRXJdp8FtW+frVzIef9vQchMWOB8JlJcSW
/BiChwSMdEwRnMdWVtlhGZf+Ah4dfn2EIWAmUujpzNa8yDkQYhduYrj1VC+6F7t4
G1tGHrPvlFKmX3YCWrvmmsvbq3ILOqSgPcPQa9je45CvASDQPt1OekKgy836iX9r
QSpne8EfdENb16S32WWymtmRtnaSxgoPcqnyV/azQHLtVywcIPUCd5DI7RTdj0FE
Qqlm9UdakseivlkP6RsvtZ8zS1lxhNkcqrlBOZSgzDFUmPLmkyWgxFpanoT8qLbT
gbEjTdmbQhy9Z2tLD9hbsbqkBNlAoUz0fTd6jwIDAQABAoIBAAIlf8T0E3sdCQ2S
Zcoe9mzbGduIt80eIHwCU6Gww7uBTbkOI0EGJg8BlauZkddCA+qQTtL9wWvRaVnA
xzuMdK8y1E+KnVKAtZ4m4XNJFX58I4JNEJR3sAiPCAP8jrBBUoJGP//PdfNROqcA
kCx3HVdeomCH4EzJVxaTv3t2/4PSDYRRLobl2fEWpMmKfGG6LY/enwreuXnutMy5
YcI6lDQKB4WAViKbR7jSAtDRH4fc56cXiJkEZpTe+ex4qtTUvuWMDKElDZ0AXCF/
jWq2ZTJS1AGAmN+aUNr836Ts6UmHyfm9Bzfd+UBMPi/nBImzL4EJwz42Fcob2xUk
BOAN8eECgYEA1vmrxFWlMeeF0Vu2nQf5IegtXTl7wmm5YPzidcOlEr08lFR3njbZ
Vz/nd8m9u+RCdR1m0yyKcVtSTYG8vZ1mamefu53vQN18iCtoYmvveDpVBIb1GvMa
i2GsaLJzl77BJAqrIuzTvtjCh6L8Ru25yzvj85u2dyebzDy5wDeLMlcCgYEAys7V
3q6oR+Im42x0mFBtM17gpr0tWpA/IxX13L+mhYit3B95QJPMKKUCf0PZJEiILPCO
S7l0APwIBS3+GBy9bGNvnxy+lqx6APKkgv8AXEy4//byWJQe4K2HR6DqahkT9eWj
QfhKwpdWxXmP5nJXP0sxr2Cba2jROw6xkneghokCgYBrxybnuyykNXgwu3N1jR7J
chb0SzKSCOFpD8AV3K2xFHD/yM1j5AnZJW/N7bYTMmBjSQdZTlZmeKttsmLHCdfj
9untbUQbWC/sMR8XYRfhRhWDvIm8Ji+ju6dtojIz3O4GPNcKHoQWhaQZzov+n4br
rq4dX27+lDwXDEbwaKh/5wKBgQCHLSm8DSo5D3HgMA/e3eyLSvft6zXpoS+UETUY
99zkMF/B0nCdLGXtyV5KuUxoNLgfTA9sRaYead5mpWsxYyaWsghaQ2x9PWTscM5a
SeFRpAnDAjQx+jhChScgBQ95vFFjmrYgaIBcB0dcxFO3xAqHM3VgccHl661Z8cdF
2tpyEQKBgQDWjOpQV+2UUucwlP9JeOFz8xvWFk+wV8cZmHcUvsRlPnnoU05XmTSq
krYyLqOlD5jlapAKEmYRzMBum8hCUyO9708n0Os5K5bH+B9ehEKDOoFoqjEMq03y
11GkhypIDpMTWbJ3KthERYJcI6BLB3fQMM4xeaTvgid3gJl2iZZWqQ==
-----END RSA PRIVATE KEY-----
KEY
        /**
         * -----BEGIN PUBLIC KEY-----
        MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqk6yCd6plsjib2dRXJdp
        8FtW+frVzIef9vQchMWOB8JlJcSW/BiChwSMdEwRnMdWVtlhGZf+Ah4dfn2EIWAm
        UujpzNa8yDkQYhduYrj1VC+6F7t4G1tGHrPvlFKmX3YCWrvmmsvbq3ILOqSgPcPQ
        a9je45CvASDQPt1OekKgy836iX9rQSpne8EfdENb16S32WWymtmRtnaSxgoPcqny
        V/azQHLtVywcIPUCd5DI7RTdj0FEQqlm9UdakseivlkP6RsvtZ8zS1lxhNkcqrlB
        OZSgzDFUmPLmkyWgxFpanoT8qLbTgbEjTdmbQhy9Z2tLD9hbsbqkBNlAoUz0fTd6
        jwIDAQAB
        -----END PUBLIC KEY-----
         */
        ,
        JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA04K1bBibvAV8tjVFmwVe
c+3gmpAQRJa6ac4Ht70m1lvqgrtqMoxaG8Jsj+9zPVaaLN41352Xj4xdhMp+KOZl
vukzcvi7ahq3vsCQdHcffukCU7U/SwNf6wDVfQ5PW5HaYyanH6PlbZi3SA+bowsM
7cOKsFaMy0mwZ72QWrbA2AWa81ce8TgkYQR+wPAxye0jzz/Y7Gm7hO6JIqSVlP+2
FGzeqbGkKS1rrtc+pjLvVlOlYcpPCwUkRflQJ0ePsOL7K4VrUhfc3c8qrvB43x++
GXY3mYGK0kZieRc3IFaQVTeOivX32ZtuYn+TjF0G7vruR5GSlQYV2yorG+HTF0eO
RQIDAQAB
-----END PUBLIC KEY-----
KEY
        ,
        JTPay::CFG_JT_MERID => '631310060050023',
        JTPay::CFG_JT_MERNAME => '正行IFA平台',
        JTPay::CFG_JT_HOST => '10.198.40.102',
        JTPay::CFG_JT_PORT => 9521,
        JTPay::CFG_TIMEOUT => 5,
        JTPay::CFG_BILL_PATH => '/srv/jtpay',
        JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
        'sn' => [
            IdGenerator::CFG_MAX => 98999999,
            IdGenerator::CFG_PREFIX => 'jtpay:' . date('Ymd'),
            IdGenerator::CFG_EXPIRE => 129600,//1.5天
        ],
    ],
    'jtpaySplit' => [
        'pay_money_min' => 11,//小额打款确认最小额,以分为单位
        'pay_money_max' => 99,//小额打款确认最大额，以分为单位
        JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEAuu2/z91PPtpjpq7T1GXBoksPylXFQ2UIIZqLEH1clXeGn7eM
NlCCieWf/TR4h9iMIRDdJQOboZQTIp9G04HxQhRAF3ZTa7IkebgSC2Z8QrK/ZY9Y
ufwVWpOb8CEI+XsE30eQU0LR2ZWOw6wktJd3Egki43L9xRdU5h4Zl9ssJ2qJeFzn
B6iQJ00/D8vwweEhEsqvJAUnWsnGxeDmxhOI/A1yQgOH2hJsUKORDqyTM+0bGwaL
guudrOJTYVK6HMKEdnlXwVuXSrmm0VrnZFwGfKUTAZypcm3XQXAD6xg2n5ppF9/8
rgMR6vvxAGtM9CvT/P5AHHzZAXBE/pWj8o3JuwIDAQABAoIBAQCvar8O1PMx24Wa
fQPClT8yCtilmvnENgJ8bmfEMLB6fzExnvCQY9sshvUti1j0um099nJg8tLQvYF7
gxbXE2ERDqnamqrMLN937hnY4vMHMHDWYL/1wK9VUaILpSSj4iL/WUwCJnmBg4z2
6QuFAYK2xSYdZeLpWuzMCkEgNYho7z+89VV14VaH8cDM0a5UYSxaZhZTFW0gdfrZ
gRMh/P+gsmEBE6izOWBl9yg6owb1bjGhbQo2cHaV9kbI/NsE6ytFafCPKBhQ/ckO
1DdmDNy48G6+iBy6kWtbE28JwiNAIUt6VWL4vO7BLRNA24rP2JdMg2fBkU9rfvPe
zq7a4Ut5AoGBAPGMgCs6jsb+LNb0KoXcAwYMauDYiDB8OEKuxbfPziFCCOS/J+9d
4yFy67RimbxN/TWza6kPRkckpP2K+boh8ljPGhRHTdIP5hnxRIUK9n8J+Eiw17oS
Lt8+JZfcdmUE9YHnT3JQlLXkSKZkR10CUzExxOkPJcFInxQWu/7EMcn1AoGBAMYc
s3GVEdeKgPQbtBX+lSdzrBbvPkaUB4wozjtw5hjkx4s0BmQ+65UDCpVObqIhyy+8
laMas8HGIPO4mosL+Xl8kWJ/7sdE4fPUMrajsDwrWnxfSN2Q2NultJD1DGaBUBfU
mSBj93eV+soc3ytgMX4wJmdPovi3Tfpl9c1RbIbvAoGBAKDm/tnNAB7+YdAuhcT1
ce4th2SP2OizVqbU1VBEVQNCgboeu/Nvj0VQ0EIxDEeri+ihxC2xxxbNCjr6wK+E
vXL7QlwPw38SqCzP0tztGJY3hfSmGI4SXrbHJzOp4BQa4Y/PDdUQaH9huiNc2UzT
p6c1h/3X4UaHobA4FLL47lGhAoGAYNd+0DLyec52ot039thvyM0+fieM5atO1TDN
Pzk9AUY0VNOlnDM1ra3C6qFga1jhngAtlYFkBYD4cqr2wKml1cESwHeRHU+KtEoy
UB1L9N2saceaMtSvbQ9faMygtyrXIA8Im1DCk255HXtnjCiFiQ24eB/xpmrUb2aP
9UGsL3kCgYAq5pUsK0YlNz0MVY7slctTu+nVV66n7E2OP2Wg08h5sIqmi6YTKtdB
LECFbrryBI50hGgbThMh+C/B1usF1TGGowAf/koOfrtcCD6eOKHrMQBi7ngIRJVK
76QIhjs3VGMGtLjMH/CY6Ts/VH5hsvrA1OoJNCQhYVcSUiV7vM8x2Q==
-----END RSA PRIVATE KEY-----
KEY
        /*
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuu2/z91PPtpjpq7T1GXB
oksPylXFQ2UIIZqLEH1clXeGn7eMNlCCieWf/TR4h9iMIRDdJQOboZQTIp9G04Hx
QhRAF3ZTa7IkebgSC2Z8QrK/ZY9YufwVWpOb8CEI+XsE30eQU0LR2ZWOw6wktJd3
Egki43L9xRdU5h4Zl9ssJ2qJeFznB6iQJ00/D8vwweEhEsqvJAUnWsnGxeDmxhOI
/A1yQgOH2hJsUKORDqyTM+0bGwaLguudrOJTYVK6HMKEdnlXwVuXSrmm0VrnZFwG
fKUTAZypcm3XQXAD6xg2n5ppF9/8rgMR6vvxAGtM9CvT/P5AHHzZAXBE/pWj8o3J
uwIDAQAB
-----END PUBLIC KEY-----
         */
        ,
        JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA04K1bBibvAV8tjVFmwVe
c+3gmpAQRJa6ac4Ht70m1lvqgrtqMoxaG8Jsj+9zPVaaLN41352Xj4xdhMp+KOZl
vukzcvi7ahq3vsCQdHcffukCU7U/SwNf6wDVfQ5PW5HaYyanH6PlbZi3SA+bowsM
7cOKsFaMy0mwZ72QWrbA2AWa81ce8TgkYQR+wPAxye0jzz/Y7Gm7hO6JIqSVlP+2
FGzeqbGkKS1rrtc+pjLvVlOlYcpPCwUkRflQJ0ePsOL7K4VrUhfc3c8qrvB43x++
GXY3mYGK0kZieRc3IFaQVTeOivX32ZtuYn+TjF0G7vruR5GSlQYV2yorG+HTF0eO
RQIDAQAB
-----END PUBLIC KEY-----
KEY
        ,
        JTPay::CFG_JT_MERID => '631310060050013',
        JTPay::CFG_JT_MERNAME => '正行IFA平台',
        //JTPay::CFG_JT_HOST => '10.198.4.4',
        JTPay::CFG_JT_HOST => '10.198.40.102',
        JTPay::CFG_JT_PORT => 9521,
        JTPay::CFG_TIMEOUT => 5,
        JTPay::CFG_BILL_PATH => '/srv/jtpay',
        JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
        'sn' => [
            IdGenerator::CFG_MAX => 98999999,
            IdGenerator::CFG_PREFIX => 'jtpay:' . date('Ymd'),
            IdGenerator::CFG_EXPIRE => 129600,//1.5天
        ],
    ],
    'jtpayBroker' => [
        'pay_money_min' => 11,//小额打款确认最小额,以分为单位
        'pay_money_max' => 99,//小额打款确认最大额，以分为单位
        JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEArsI12N1AQwnP4WZDiHBSiXdx20NljXPw4C3KmUg4VQFUX3k2
iMJg10s7dCd8R0yQvDIHVO2p9EUghqPiwg0Wpm2dSueJHOBC4lNiLNV/DVpeXlh5
dynb6oUDnAqjp35MnqXp+U+itsY3dkmSWvBNdxjS8csBx8koF3NNsBXmG+HRNSlR
Jj940xqNr/hN2NWIl9SLKr8lbrV2VfvilhlcMgKD93KuaqhKEyQAXqNlBkosZHu9
5vAb0R7cxKR/Ys2K47PIELfHH4JL0c4Z154BTWUTRerInzuCxHHCvDhYikloSQPR
8JiUQ+Fpv2edgMR1/mSPTo2dFL7JkX0WJDD9/QIDAQABAoIBAQCj+6j7beE3BqYC
IyuLg5pvU52K2ZsZOIn2UgGiA5qYaT76t4rsmTi1zOpk/Agp/zZw4aDvmHO5uoPi
0zWcURvH32ORPeHzLpyUMxoUZ+FobjvO28ZegvDRBy9z5KfcKy9KTvVV89wDFcxF
OpQSsRp/ftOx/4QULDVqi8+CQ4pA7f+VAeNWRy3e55+v9bkULodAnhuxgIJzi1tP
HeTi2DkXLzGp59nbnZaimRZ58A7cidawLNiF+s99gLEnNOTZ8yox+j0fYrjq9XFA
xe4w0q5AK8DKP8OQ4x1QU4ngmFUQuBWl5seC3wNAlE6TvbnrWlfbraRrdlAKcpTX
U+VsZ64hAoGBANdz6bAe08akH49+NeqThrwBjXn43PRqP4LoC2QdSE9pJpj9XvFe
w2AnMx6BfcWmJw8VPENMwGCPNP7euw3LAdwWkrIY6XD6EQaLFvdQvjAJu5AbF9dI
aNvsp1uuCo3/XgBRDZTlkNHRd28RR3RxbD02IUcsKrGFHeYxjRK3gvyHAoGBAM+l
u/KWWLq3kP7UMFELy5I14GBKgqD3FQK9D/Lc3uvAIerORwJm8mRgPHE4eEb4ZT2j
bFXKbbgGmaVACbKJ3/r6IuvVPPe98ZHH1ZyFVraCmLC77DqR11rdULzTn39OjZky
48Qc9BXW24u/bN3shndd50xtActJjE9Vxu5XrXZbAoGASkE1yjBltrF7+x15gZZE
umkilGYT6NzxdLF6s49wC4Zm+hVg8nlBhtMbyCjC6yq/jXA5K8y5BM52alzjRPax
dmQFPQJe+kQFOCcZzDT0x2OjVCAyUE0xbpKaf3t1QclAYYWN08Jm7hluO0ZORTCO
KG6Oe5QaRsJlMp/jSg8bQuMCgYAo0YifyGRK2Bj9rxKMbAgphsPDygHhyJBtyGKh
OD/uEgfY05Hr6/bMOorHKvWh5eRo+H4sYy2sVkfPz0XYvfe0q4U/3NwuSz14jdL1
ANUp7YQ8gcSPQuoVp5nedK9O5E87hWB2xcZJoMHpt8ib24oXXvM/99G5d4zIb7E6
WyvzLwKBgQDRmpxdeBBcf3rkZ+ARKoHvwkmq/z69KUbvO8yGjHIQgUL6Gt2XO5hf
75C1BAfdbr58PMQzCPJKElEUGv9e9uoqfqv0t1bhBTW6cfg9v/j00DXZwp8lk99b
IY20w98Z86n3NSHFGsV4Ua+1IJ1s3tiVsZb1Lj8E+lNdmfGieVjflw==
-----END RSA PRIVATE KEY-----
KEY
        /*
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA8aWtkKlVbmaHId8ZCkUm
WrC4QOb/rjEN8TVGTzueCmSAzWxJUAdDJlWwUQeq8AuD5HIUW+CAPKPkdZ812amm
PbDjdPi2h290Qz9CtGPMrpAkWW3/F+d55YVEcCQ3dIDHAhBocCgD3lWUarrCV9Iz
2EiKA2ht/8DATFhhLrGwekbwdoI4J6r1CSbePocWY2Rlo47/9vfHY9sSwMnp4Hhr
MjZmCymiPuKTUjjvhSLexdETQt1P16xah6JtGFyH3gHnhonhYvU+ABASidDmmevn
ymNJ9C6P9KRYRgCHkdxCIPh+X41Hsk3wIvpPj6NMMO+cJC/iSwr+/Q7+Gb2ztHG7
3wIDAQAB
-----END PUBLIC KEY-----
         */
        ,
        JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA04K1bBibvAV8tjVFmwVe
c+3gmpAQRJa6ac4Ht70m1lvqgrtqMoxaG8Jsj+9zPVaaLN41352Xj4xdhMp+KOZl
vukzcvi7ahq3vsCQdHcffukCU7U/SwNf6wDVfQ5PW5HaYyanH6PlbZi3SA+bowsM
7cOKsFaMy0mwZ72QWrbA2AWa81ce8TgkYQR+wPAxye0jzz/Y7Gm7hO6JIqSVlP+2
FGzeqbGkKS1rrtc+pjLvVlOlYcpPCwUkRflQJ0ePsOL7K4VrUhfc3c8qrvB43x++
GXY3mYGK0kZieRc3IFaQVTeOivX32ZtuYn+TjF0G7vruR5GSlQYV2yorG+HTF0eO
RQIDAQAB
-----END PUBLIC KEY-----
KEY
        ,
        JTPay::CFG_JT_MERID => '631310060001013',
        JTPay::CFG_JT_MERNAME => '正行IFA平台',
        //JTPay::CFG_JT_HOST => '10.198.4.4',
        JTPay::CFG_JT_HOST => '10.198.40.102',
        JTPay::CFG_JT_PORT => 9521,
        JTPay::CFG_TIMEOUT => 5,
        JTPay::CFG_BILL_PATH => '/srv/jtpay',
        JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
        'sn' => [
            IdGenerator::CFG_MAX => 98999999,
            IdGenerator::CFG_PREFIX => 'jtpay:' . date('Ymd'),
            IdGenerator::CFG_EXPIRE => 129600,//1.5天
        ],
    ],
    'jtauth' => [
        JTAuth::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEogIBAAKCAQEAoLB1Qi6Oyu5QDIkPrG2qahyFHaK8PRlW9Ki9bBVGSpHyF4YH
GbKs5WtjcXWrqbiiZUDBE5A8rLPRzOOBmRSZQ9QZZHMW7AexRvQwQnBobvijaTYq
2HrulcuAFpcHl3QgilRXpC00ibYlm9BMa9FSIZapXEbDqZxCdM7EgSnifWtvRh5Y
ye/I3U1tftrWkpY39YkkYHhPb8Zci/xIJ37zvVaURKYQtcGhugaPvWdcaCMhQoZo
3ZH9+qd/FaLgsL+QMDIc6kGpg9QyF7DG1tWFWxLrNVdirjJzV0oAFw2aKDUx0xAR
Nj8/wZ/XWXxtJ5kn2/Z2v0LPDPHWRZFcAFZ95wIDAQABAoIBAGY/on2YbphGiH1R
gb2wkq2utC2lba5bP2+zJ8VszCuLLsc1K7N4dHgPm1mJDNCUghF34OP39gPW8Hs1
kTO9XcFBZ175tO4//tgtbb/5Exr579F0/FJ/9u0ubrTxKY2AAWzEOnhno3S1iLzb
EKXSrjZdTis/hCWbHtaA851U75/qCOMw+Wwggbr0PO+v2uhaPt8phboZpStDsPNx
NFwiOzQmF9OnsF7C4Le243y6GUJKtmwIvd2SkHBznfr7M9H+sI/cTDJ1Lm+TxCDI
ugSZpugs5er3daqkIXViCoSozgsEBMcnADwu44dEInlAs7ZJGcMv9RVeY/1pk3MX
Uhha6kECgYEAzTncbMAnnMPwTYNvmcau64SlyCfamstEQRsPO5H1N7r8lIv6VViA
MBAmzTUl92ixe2qJwtV979aXKAScWFYe6PUH15nGzWRJCZ5BTHlLWqi3iEP/W20S
nTHMZkBKbUPr/FH7qdvuM/D1wL9hQW32fbTXeX2OHj5v7wG6sw3MGPcCgYEAyHHU
smNfNkfPYX7rVpQCQ9NjiGXy4TeKEvNJ2CmzSSywYllKCfmUGZScmBdKub9kVaRT
9IIKkIjvp44BDUnUJFxlMMgXjaDAbq+/C0tPPMU3b+ihbqGNxPkcNziVBQPmf5rE
CdO/UB1HVDb1F5JRTQBAfj/IDmyrhOSSbRV59pECgYAYDko6LSP3ijgmvdtdCR8D
2F6eYZ2MO3tarlNQxkEaMT7eIrJLQr5z49DIiQxUPd9f+hL/1YqXjG3XcQLqj927
rM0ohov5E2JEUFqTHjyo+dHZlS7fhp+B8Y5mBe8zc5y7zNhVBsSbLgmAeG5r/vm/
rmz7fq4j+WmheHBsAJgF7QKBgBy81TXOMXRiz0S3IZ6EEd8Pi5GerDfF8rHM16V6
NQ4krhUroAXWFnmkaN8VV81Rt1zf9nlzu3gFafan0VbKYvPjm05nIZlYlr5HzCge
X/nifJQ60go+d0jqPjVck2Dosj9RPRH7nc4qpHNafcEnZSiZBKYVFuWahuzCqIuj
LJ1BAoGAB3qjpYX3TIDxaCr+sGxYHL6ugfpr7qowLSty59gVdtOMdoF2LDZyNGlT
bkY+wWdELp8gWx5gxspji/XEbzL2AzGICa7rgsyqg/VNqDJC24XTNbNRu4HPJFBK
8lBfdbZrTB8GapHwnQ3XME3dW6sO9SKuDLBrYDQ+7avEQuA2Kzo=
-----END RSA PRIVATE KEY-----
KEY
        /*
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoLB1Qi6Oyu5QDIkPrG2q
ahyFHaK8PRlW9Ki9bBVGSpHyF4YHGbKs5WtjcXWrqbiiZUDBE5A8rLPRzOOBmRSZ
Q9QZZHMW7AexRvQwQnBobvijaTYq2HrulcuAFpcHl3QgilRXpC00ibYlm9BMa9FS
IZapXEbDqZxCdM7EgSnifWtvRh5Yye/I3U1tftrWkpY39YkkYHhPb8Zci/xIJ37z
vVaURKYQtcGhugaPvWdcaCMhQoZo3ZH9+qd/FaLgsL+QMDIc6kGpg9QyF7DG1tWF
WxLrNVdirjJzV0oAFw2aKDUx0xARNj8/wZ/XWXxtJ5kn2/Z2v0LPDPHWRZFcAFZ9
5wIDAQAB
-----END PUBLIC KEY-----
         */
        ,
        JTAuth::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArOTTZd9r90jy2ZaspKuA
x4Konq2rCPhaaiBe1fwUFRe4YC8YFQmAA0IzkC3ZYVOIxkQ/9EX4XI9dOLCQi7Tf
IHn9sYQE49m6ETq/rWzLV6bkY534j95lvrmMy9jVglfnuj2NsDtuvWRq+i2+2uR+
wpXmQ4O53vO0m0j9JfCpIFcDMOo0Rhcd5a6rar0oVWc/uVZU9WONo/hhnupSUVZx
NKVrh2qxPHV73pv4ZFnzBF/VgNtF84/vKXBXiMCme/q+NUAhsyRTjFwx90T510Ns
p0rd6+j+s6SzWEv66eIDBgq8OCwrLCBVO4jStWgY7BM+AYuGXRglOE7pRVmS2HwK
twIDAQAB
-----END PUBLIC KEY-----
KEY
        ,
        JTAuth::CFG_JT_JGID => '100000002',
        JTAuth::CFG_JT_MERID => '530000000000000',
        //JTAuth::CFG_JT_HOST => '10.198.4.4',
        JTAuth::CFG_JT_HOST => '10.198.40.101',
        JTAuth::CFG_JT_PORT => 9204,
        JTAuth::CFG_TIMEOUT => 10,
    ],
    'jtquery' => [
        'pay_money_min' => 11,//小额打款确认最小额,以分为单位
        'pay_money_max' => 99,//小额打款确认最大额，以分为单位
        JTPay::CFG_JT_ACCNO => '600033029',
        JTPay::CFG_QUERYACCBALANCE_URL => 'https://10.198.40.101:10085/BankBusinessService/ws/blinkMer/queryAccBalance',
        JTPay::CFG_QUERYACCTRANSDETAIL_URL => 'https://10.198.40.101:10085/BankBusinessService/ws/blinkMer/queryAccTransDetail',
        JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEAuNHIkMQ1qbK2R3ffTSXPjbu9fqA6qv20QH9PSft71U2YBzv0
58T8QRZneN2Dab25BpNSW7L5tkgXGRBqwLQo3p58no4G+Bg2Yz0mbCoa2kGNY5xZ
YQohT9QsJ6+AdgC8jVqL+eE2oK8815LcVA3+IXxEjqykufGbrYFRxOPRKpYfa5Rg
zDNStAhN0Y2m57pqux0pjfQct/zJN2M0vHiHE1er4gp4BRg7OIYrGSflvlEk6+q7
B4Vde4wxj4KyB2vkWhyF2+bgscFi4rCdYLCfbZDoomOokBJ8Wo4RRtQC72bxl1Cu
mOKDWSDvkDJj3HQlatE196W8M93d5gWuPxCGOwIDAQABAoIBAQCqLL+4THH85wjf
lYiOyJnrr0o0JeTfPOuT16VyQZUsOl4ZiyNdpQuAAtkTeSNfYcnUPCJBPPKg3JAo
C+2/siNPmC6275+LIQAzMEMIpVxESsedSIEj0OgLURm3EOn/vX3fydfJJY3fNnuX
IyqsWpX8zydxF5Y1gDoP8FsSJ5KY2kB4upXXDBzAnz/uXOr0bM/9aEC93NXsOKHr
F3a1M21zDByagf562kS2uWJQIv30DfLSzcftU9WHoBOZTj2RoI4qo7xlBQxf/kOY
z7IrlEfptmLYLWL2WWEgo0nXlqhUWFEB5MI7jy72QYsKx/efgR416rnOMqbgzGvz
oBbubnABAoGBAOgnjmAZHpEI3JQFlQFPYZqRTDhaGGgvOlNhV15eB5XvROFXp5GZ
Pj8L/pLHvGisxEmUQqqT15PNSSUovx8EgUpXybY27L7i02xrW/ZO+BrHZmV2APO6
g5ZQzgHw3/KJQX9zqkq+G1lJzMMemnXP5rn5n5S4RRmwcKnrVJkjkE87AoGBAMvN
kHHpi2Po428S4fhds6YAgv4kJ6TiS9F9J6AmILMSyr2dorNkCtvTe4ImS49u95Cj
2K/ZV+kgk+kqyVCPVDhJLfUtcE0GX8/htvXlIb9Wc37NJwdbfvvIxdGoJqIV2C21
mJfqUOCGhQGG3D0G2Pof8MYrRE7xCOTVekthuzUBAoGBAIrjX2JOpOLQEmbcEBEA
lLwMQTVVcVSjLJnFmqdySceBpgvKjQ2mSH8fheX6aNWWxrfeYyP53vcl0aTRg8Xi
xBbd/mds5KYuvZ4XfKUXCYe7057PwjIOW7sKDLVMji5jvzOo1zBwG5yHcmEpZe8l
ujt5A+fNdkmwLTb6+1nC1QsRAoGAdO3nHwQwvkzjGFpMHfSc2vRWM7vIpxhTCcl1
z7OwdS2l9q6Xp7cRZ9hpd13DYnL3RRxMeXAIuS/AzTmIMVlap8SMwqukT/0FQb8t
+tzQxPez4h+Qce8z5v/lR4njSIGh+2/CMf71Eiz76MlYWQcxvChRO1GdqnEueiRl
OxTClQECgYA4GEraXrm/fs9zZnHUHAOG5/HkLjK+Pbklgp8+WKqu8mAO1kb74f8i
cwKW+vwqhTDhi2S0jBn8L9pvH36Yam0rlEsTu7JlzLRvPhU9YuV+8PbBtEHrjUnd
eEepM5rSqbAXCx5copw1jEi5dfbLkVjo9Iaq7RCjFc59P3xZmEZCLQ==
-----END RSA PRIVATE KEY-----
KEY
        ,
        JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxy7MOJfsBky6q62gUImC
mN3kyiSvcgv0yKkMZYhXPH6dIsoXm59WVMW0AA2NtssSm1+SPj+sxTyx5tK2BEIz
yL5AFPoP06SubhKwQdazcdRLq637hwZQFBOqwXNfvTaGoS1c43kY3fMqSbv3ff0V
MZbqx+BmF141cwyRxZ8GDUmQNr7LFDHBrZm/GhjX4ijRLZwMUUYqqIeY2tdPYH4I
6Akp7lWRrUM16IzEP3ZwZc0VG1lmdEM0ptrHoq95ecM6yIzUFpBbqA0WA+cPkiah
JWk0yoWTCzfQPAF4MWhZe2p2FHsvhlO4EmRG4tBxn7lXxK2zHTDfazlHzcUSyk5Y
7QIDAQAB
-----END PUBLIC KEY-----

KEY
        ,
        JTPay::CFG_JT_MERID => '560000000000000',
        JTPay::CFG_JT_MERNAME => '正行IFA平台',
        JTPay::CFG_JT_HOST => '10.198.40.101',
        JTPay::CFG_JT_PORT => 10085,
        JTPay::CFG_TIMEOUT => 5,
        JTPay::CFG_BILL_PATH => '/srv/jtpay',
        JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
        'sn' => [
            IdGenerator::CFG_MAX => 98999999,
            IdGenerator::CFG_PREFIX => 'jtpay:' . date('Ymd'),
            IdGenerator::CFG_EXPIRE => 129600,//1.5天
        ],
    ],

//jtmpos Added by liaotao
    'jtmpos' => [
                'pay_money_min' => 11,//小额打款确认最小额,以分为单位
                'pay_money_max' => 99,//小额打款确认最大额，以分为单位
                JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA42SlLDwVVaVeJ+WO/vhs2Use5PSrjunlG0iQKHMdcoTd7swN
JUK0NxQql9N14J0HgML6boRWh14aOa0Uqio+dtk2dAtKVbLxD7qVIj1qPNcf5wmC
4VGtokojA+ZRBbgN0VOSCCe6XwaIGoe/zcw7qEVICnTImZLHIk/No6hlzoz3u8Xl
63Pg/tekA6j9sflxk/AK64guhE3FU+LwYQ5cifi0USruXoXOcmceBXvuwgoOv65r
lVGJRpuvhq0vx+HhZRcyfz8OJp4aR1B5XiUvAVk+2G0Rbux4QcZOgYsigiES7iyM
esyTzM2W6qsfzsTAtLAQ1p6W2kRqE+9pKNO1vwIDAQABAoIBAAVxpmattZEMWXm5
DDhceDanjsDKfsT4Io0JqrHdN6pDNhD+f54Rv8DF0dM6s8rB16kkgdxdfLjW7ufM
lf8Q7dfokV4r2wa8Nvs6a1GbiMyWFeRxHNoKG48UGUyBmhT5+BK33nolgVe/D0kb
UOM7bX400mm1rAvJMM1IfdLaOD2+pKkK2OhFTQxEWbhSfMf2gXO0mnZrLylxdOEa
a1y+dZ6HgshWJnNUbJ7bC/tV0maZgaluuk60Ag7uMigC0PlkjRWk2XeMy98mRGd1
iKyx4/johtIowpf/y3R0/Emd5cw2r1ODxo8sDWCDCPMw9kS/ykyqz4IIgIJydGqi
sb3H/vkCgYEA//fyq/Ef2q9XwSv0ArnSGPF88PUGpgvcrg2lEizF619aMKei4KAe
7e/iChtwrc1QLzmOkosWLgHvlDLsH062sSupEXgHkcfWrN5EnNtEvOYpQ3YUTCzP
FA85zzUsb8IxbNW6qLZqIXxh0a2yWLCjiDe2+cuyw98Xz0BVzzHsBFsCgYEA42vM
YcUaijcfn4KqhWt2P6LuGPr4DnyVQpV9QwLfy+LOmJJfn9ugzq35mfhvJsgI9rPo
veKIPo/ZIAZrkf0+XQ/Vt+MdeXExjhZVbN8iQQcJhSS9ezjqFa0C1LJQwww3g8yO
65t+lXcF4erqgfwE/F7FLRhMfX4y08FOz+SsgW0CgYEA3vsdUIG+ESA8XxAuAg3k
I0yDXdjl0NJ2jL1gNmQAillHVSlDr1BtgTM+gzWCRDWeC3WlaK13Rd7z2PM/VMqa
Rd7V6lzYozsmHPOHa+lriO8rtRPw/KbwQfY9ku8sZbMSoU/SylQWQlN7V1BsE+zU
mL6ITDUR5qW6tRXDarp/cw8CgYEAlIANg0IbZGk+QwAlrN1Q55jSdIlcdMkxBbtr
gdhcnlvJn6LkwhO923eK5tlsaxxvjfhIX8WORZvUoa7PixKcKFRwr5Sj6GrbevZm
baL+UQvxUXl+KPovEFxa3txZFCPkFDH8mSh97cc8lhq5aotQDiMsCZg2SjOfqNov
Rl0Br7kCgYBZmtOUE3eLqQvWAOMbaAsnXotY/t5tFqV8t9q6W6N0Nu4FknZVZNNg
HDG6f9RV4Ir7Cc0Rd1OyBXHrHH10rx95NiKXp0x+/Q3Pdpb/PDBrKI2OfXqu0ozI
6Jb9WSblScE8MhcSISknSIA9p0Oqlqgm/BTcB4OBP7FEX+HxV4ipBQ==
-----END RSA PRIVATE KEY-----
KEY
                ,
                JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsu4GwZezzY8NwrlAGIBu
A+wP763B0IZ2d6gXRCf+IBWjajqtQK1GgvHPJlEPJeOCcsT+ZUYdidImKUzFDqcI
E6rrdJ9R+iHkb76jjjcGL5cd6l5IDJXvrY1RhXef3zc0YZSteoYtIjO8/WgotBgG
nqHUivzFS5rY4fTlRr6cgmv85NiiYW2Y2dMMd5LRJdiLGdQQZijop8ojvpesyrwJ
xRPq1GLHaRsmTDSXH438DoWZZ42UZuT3xJyfzKydEF+LAbeIln/qQKZoMwhPCqpl
XrFdWTfLD5kvNQgUWplCF2fr/P/ddgbblS/CQGQeSZho7C7yhVqWtfswnc4SdNw3
9QIDAQAB
-----END PUBLIC KEY-----
KEY
                ,
                JTPay::CFG_JT_MERID => 'A00000004      ',
                JTPay::CFG_JT_INSTITUTION_ID => 'A00000004000001',
                JTPay::CFG_JT_MERNAME => '正行IFA平台',
                JTPay::CFG_JT_HOST => '10.198.40.101',
                JTPay::CFG_JT_PORT => 9201,
                JTPay::CFG_TIMEOUT => 5,
                JTPay::CFG_BILL_PATH => '/srv/jtpay',
                JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
                JTPay::CFG_MPOS_PRODUCT_CODE => '00000870',
                'sn' => [
                    IdGenerator::CFG_MAX => 98999999,
                    IdGenerator::CFG_PREFIX => 'jtmpos:' . date('Ymd'),
                    IdGenerator::CFG_EXPIRE => 129600,//1.5天
                ],
            ],
            'jtmposBroker' => [
                'pay_money_min' => 11,//小额打款确认最小额,以分为单位
                'pay_money_max' => 99,//小额打款确认最大额，以分为单位
                JTPay::CFG_KING_PRI => <<<'KEY'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA42SlLDwVVaVeJ+WO/vhs2Use5PSrjunlG0iQKHMdcoTd7swN
JUK0NxQql9N14J0HgML6boRWh14aOa0Uqio+dtk2dAtKVbLxD7qVIj1qPNcf5wmC
4VGtokojA+ZRBbgN0VOSCCe6XwaIGoe/zcw7qEVICnTImZLHIk/No6hlzoz3u8Xl
63Pg/tekA6j9sflxk/AK64guhE3FU+LwYQ5cifi0USruXoXOcmceBXvuwgoOv65r
lVGJRpuvhq0vx+HhZRcyfz8OJp4aR1B5XiUvAVk+2G0Rbux4QcZOgYsigiES7iyM
esyTzM2W6qsfzsTAtLAQ1p6W2kRqE+9pKNO1vwIDAQABAoIBAAVxpmattZEMWXm5
DDhceDanjsDKfsT4Io0JqrHdN6pDNhD+f54Rv8DF0dM6s8rB16kkgdxdfLjW7ufM
lf8Q7dfokV4r2wa8Nvs6a1GbiMyWFeRxHNoKG48UGUyBmhT5+BK33nolgVe/D0kb
UOM7bX400mm1rAvJMM1IfdLaOD2+pKkK2OhFTQxEWbhSfMf2gXO0mnZrLylxdOEa
a1y+dZ6HgshWJnNUbJ7bC/tV0maZgaluuk60Ag7uMigC0PlkjRWk2XeMy98mRGd1
iKyx4/johtIowpf/y3R0/Emd5cw2r1ODxo8sDWCDCPMw9kS/ykyqz4IIgIJydGqi
sb3H/vkCgYEA//fyq/Ef2q9XwSv0ArnSGPF88PUGpgvcrg2lEizF619aMKei4KAe
7e/iChtwrc1QLzmOkosWLgHvlDLsH062sSupEXgHkcfWrN5EnNtEvOYpQ3YUTCzP
FA85zzUsb8IxbNW6qLZqIXxh0a2yWLCjiDe2+cuyw98Xz0BVzzHsBFsCgYEA42vM
YcUaijcfn4KqhWt2P6LuGPr4DnyVQpV9QwLfy+LOmJJfn9ugzq35mfhvJsgI9rPo
veKIPo/ZIAZrkf0+XQ/Vt+MdeXExjhZVbN8iQQcJhSS9ezjqFa0C1LJQwww3g8yO
65t+lXcF4erqgfwE/F7FLRhMfX4y08FOz+SsgW0CgYEA3vsdUIG+ESA8XxAuAg3k
I0yDXdjl0NJ2jL1gNmQAillHVSlDr1BtgTM+gzWCRDWeC3WlaK13Rd7z2PM/VMqa
Rd7V6lzYozsmHPOHa+lriO8rtRPw/KbwQfY9ku8sZbMSoU/SylQWQlN7V1BsE+zU
mL6ITDUR5qW6tRXDarp/cw8CgYEAlIANg0IbZGk+QwAlrN1Q55jSdIlcdMkxBbtr
gdhcnlvJn6LkwhO923eK5tlsaxxvjfhIX8WORZvUoa7PixKcKFRwr5Sj6GrbevZm
baL+UQvxUXl+KPovEFxa3txZFCPkFDH8mSh97cc8lhq5aotQDiMsCZg2SjOfqNov
Rl0Br7kCgYBZmtOUE3eLqQvWAOMbaAsnXotY/t5tFqV8t9q6W6N0Nu4FknZVZNNg
HDG6f9RV4Ir7Cc0Rd1OyBXHrHH10rx95NiKXp0x+/Q3Pdpb/PDBrKI2OfXqu0ozI
6Jb9WSblScE8MhcSISknSIA9p0Oqlqgm/BTcB4OBP7FEX+HxV4ipBQ==
-----END RSA PRIVATE KEY-----
KEY
                ,
                JTPay::CFG_JT_PUB => <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsu4GwZezzY8NwrlAGIBu
A+wP763B0IZ2d6gXRCf+IBWjajqtQK1GgvHPJlEPJeOCcsT+ZUYdidImKUzFDqcI
E6rrdJ9R+iHkb76jjjcGL5cd6l5IDJXvrY1RhXef3zc0YZSteoYtIjO8/WgotBgG
nqHUivzFS5rY4fTlRr6cgmv85NiiYW2Y2dMMd5LRJdiLGdQQZijop8ojvpesyrwJ
xRPq1GLHaRsmTDSXH438DoWZZ42UZuT3xJyfzKydEF+LAbeIln/qQKZoMwhPCqpl
XrFdWTfLD5kvNQgUWplCF2fr/P/ddgbblS/CQGQeSZho7C7yhVqWtfswnc4SdNw3
9QIDAQAB
-----END PUBLIC KEY-----
KEY
                ,
                JTPay::CFG_JT_MERID => 'A00000004      ',
                JTPay::CFG_JT_INSTITUTION_ID => 'A00000004000001',
                JTPay::CFG_JT_MERNAME => '正行IFA平台',
                JTPay::CFG_JT_HOST => '10.198.40.101',
                JTPay::CFG_JT_PORT => 9201,
                JTPay::CFG_TIMEOUT => 5,
                JTPay::CFG_BILL_PATH => '/srv/jtpay',
                JTPay::CFG_BILL_KEY => '0123456789abcdef0123456789abcdef',
                JTPay::CFG_MPOS_PRODUCT_CODE => '00000870',
                'sn' => [
                    IdGenerator::CFG_MAX => 98999999,
                    IdGenerator::CFG_PREFIX => 'jtmpos:' . date('Ymd'),
                    IdGenerator::CFG_EXPIRE => 129600,//1.5天
                ],
            ],

    'erp_order' => [
        //'wsdl' => 'http://10.21.200.65:6969/InFactor/O2OUpsertOpportunityWS.asmx?wsdl',
        'wsdl' => 'http://10.21.200.65:7373/InFactor/O2OUpsertOpportunityWS.asmx?wsdl',
    ],
    'hs' => [
        'baseUrl' => [
        //    'http://10.3.3.134:7001/fundapi/restful',  // uat 全流程
        //    'http://10.3.3.134:7001/fundapi/restful',  // uat 全流程
        
            'http://10.3.3.141/fundapi/restful',  // uat 
            'http://10.3.3.141/fundapi/restful',  // uat         
        ][mt_rand(0, 1)],
	
        'md5Key' => '88888888',
        'merid' => '8888',
         'isSupportAllDay' => true,
    ],
    'erp_sql_server' => [
        'host' => 'erp',
        'username' => 'ERP_O2O_UAT',
        'password' => 'ERP_O2O_UAT',
        'db' => 'erp_uat',
        'encrypt' => false
    ],
    'session_expire' => 6000000,
    'phonecode_expire' => 900000,
    'yht_oracle' => [
        'username' => 'o2o_sit',
        'password' => 'o2o_sit',
        'db' => '(DESCRIPTION =(ADDRESS_LIST =(ADDRESS = (PROTOCOL = TCP)(HOST =  rac11gUATscanip.noahwm.com.local)(PORT = 1521)))(CONNECT_DATA =(SERVICE_NAME = racuat)))',
        'tableSchema' => 'oap_prod2',
        'encrypt' => false
    ],
    'jituan_oracle' => [
        'db' => '(DESCRIPTION =(ADDRESS_LIST =(ADDRESS = (PROTOCOL = TCP)(HOST = 10.3.3.162)(PORT = 1521)))(CONNECT_DATA =(SERVICE_NAME = orcl)))',
        'username' => 'uomp',
        'password' => 'uomp',
        'encrypt' => true
    ],
    'yht' => [
        'baseUrl' => 'http://10.3.33.173:8080/NoahYHTService/rest/', //全流程
        //'baseUrl' => 'http://10.3.212.95:8080/NoahYHTService/rest/',  // uat
        'subscriberNo' => 'O2O',
        'ifaNBFaCode' => 'NBHT',
        'ifaNBFaName' => '中后台分公司',
        'ifaWBFaCode' => 'WBTG',
        'ifaWBFaName' => '外部分公司',
    ],
    'session_online' => [
        'app' => 100,
        'h5' => 200,
        'pc' => 200,
    ],

    'noahAes' => [
        'kms' => 'http://10.21.200.111:8080/kms/dorado/webservice/KeyService.wsdl',
        'o2o_system' => 'o2o_system',
        'yht' => 'o2o'
    ],
    'idInData' => [
        'url' => 'http://121.40.136.150:8080/IdInDataAu/api/authenInfoApi.htm',
        'userId' => '100219',
        'md5Key' => 'I3f15155r1U9p9L1NFCHi35335E71N11',
        'desKey' => 'I17IPa11SBVs1797971575559ZO9753m',
    ],
    'jpush' => [
        'fa' => [
            'inHouse' => [
                'apiURL' => 'https://api.jpush.cn/v3/push',
                'appKey' => 'b5ec9e75acb10396733e5a15',
                'masterSecret' => '75dabd6750c79fad54665552'
            ],
            'appStore' => [
                'apiURL' => 'https://api.jpush.cn/v3/push',
                'appKey' => 'c9b533d605f848df11d0db86',
                'masterSecret' => '760ea2a682bfd9ada01eb0ca'
            ]
        ],
        'user' => [
            'inHouse' => [
                'apiURL' => 'https://api.jpush.cn/v3/push',
                'appKey' => '248bff9d95c2a24adc454731',
                'masterSecret' => '568527411e9895507e4980a1'
            ],
            'appStore' => [
                'apiURL' => 'https://api.jpush.cn/v3/push',
                'appKey' => '7ab3124cdd2564cb530c5cf7',
                'masterSecret' => '0643d7fa64219d337667c14e'
            ]
        ]

    ],
    'company_config' => [
        'img_expire' => 900,
        'company_url' => 'http://jg.ifaclub.com'
    ],
    
    // webcookies安全验证, //李兵,郭士魁
    'web_cookie' => [
        'isEnableSecure' => true,
        'isCheckDomain' => true,
        'default_cookie_expire' => 6000,
        '.jg.ifaclub.cn' => [
            'cookie_expire' => 6000,
            'path' => '/',
        ],
        '.yh.ifaclub.cn' => [
            'cookie_expire' => 6000,
            'path' => '/',
        ],
        '.my.ifaclub.cn' => [
            'cookie_expire' => 6000,
            'path' => '/',
        ],
        '.m.ifaclub.cn' => [
            'cookie_expire' => 6000,
            'path' => '/',
        ],
        '.static.ifaclub.cn' => [
            'cookie_expire' => 6000,
            'path' => '/',
        ],                
        '.fs.ifaclub.cn' => [
            'cookie_expire' => 6000,
            'path' => '/',
        ],
        '.t.ifaclub.cn' => [
            'cookie_expire' => 6000,
            'path' => '/',
        ],
    ],


    'qiniu' => [
        'accessKey' => '_gsUZbrLzcDO-vHRLojw0holcS0oaICOyrkDiMOh',
        'secretKey' => 'gW0e_B6Yne6g4AeYeIIflRsiNqQ0gafMH4CO3nDE',
        'bucket' => [
            QiniuUploader::BUCKET_EDITOR => [ //富文本文件存放空间
                'name' => 'ifa-cms',
                'url' => 'https://dn-ifa-cms.qbox.me'
            ],
            QiniuUploader::BUCKET_CONTRACT => [ //合同文件存放空间
                'name' => 'ifa-contract',
                'url' => 'https://dn-ifa-contract.qbox.me',
                'allow' => [
                    '.pdf'
                ]
            ],
            QiniuUploader::BUCKET_VERSION => [ //版本发布文件存放空间
                'name' => 'ifa-apk',
                'url' => 'https://dn-ifa-apk.qbox.me'
            ],
            QiniuUploader::BUCKET_AVATAR => [
                'name' => 'ifa-avatar',
                'url' => 'https://dn-ifa-avatar.qbox.me'
            ],
            QiniuUploader::BUCKET_COMPANY_DATA => [
                'name' => 'ifa-company-data',
                'url' => 'https://dn-ifa-company-data.qbox.me'
            ],
            QiniuUploader::BUCKET_COMPANY_VIDEO => [
			    'name' => 'ifa-dev-video',
			    'url' => 'https://o1hmpk6li.qnssl.com'
			],
        ]
    ],
    'h5Url' => 'http://m.ifaclub.cn',
    'h5TrainUrl' => 'http://t.ifaclub.com/cpk/', //方舟学院 
    'h5StaticUrl' => 'https://static.ifaclub.cn/', //王福星 2016-01-25
    'achievementUrl' => 'https://static.ifaclub.cn/appview/achievement/index.html',
    'functioinIconsIfa' => [
	    'product' => [
	        'title' => '产品预告',
	        'icon' => 'https://dn-ifa-static.qbox.me/754148152569c53d0c94c35.63354976',
	        'target' => ''
	    ],
	    'namecard' => [
	        'title' => '我的名片',
	        'icon' => 'https://dn-ifa-static.qbox.me/1285595461569c53bed94073.70288863',
	        'target' => 'ifapro://mycard'
	    ],
	    'course' => [
	        'title' => '方舟学院',
	        'icon' => 'https://dn-ifa-static.qbox.me/767067885569c53713c61e3.12732002',
	        'target' => ''
	    ],
	    'qrcode' => [
	        'title' => '我的二维码',
	        'icon' => 'https://dn-ifa-static.qbox.me/1323286362569c53a4c2d407.27651273',
	        'target' => 'ifapro://qr'
	    ],
	],

    'riskTestUrl' => 'https://static.ifaclub.cn/appview/riskevaluation/index.html',//风险测评
    'accreditedInvestorUrl' => 'https://static.ifaclub.cn/appview/qualifiedconfirm/index.html',//投资者认定
    'joinCompanyUrl' => 'https://static.ifaclub.cn/jgfaregister/index.html',
    'msgcenterOld' => 'https://static.ifaclub.cn/msgcenter/',//1.5.0（包括1.5）版本之前的消息中心地址  @唐誉
    'msgcenter' => 'https://static.ifaclub.cn/msgcenter_new/',//1.6.0版本消息中心地址  @唐誉
    'gwUrl' => 'https://api.ifaclub.cn', // 王福星
    'hkmRegUrl' => 'http://url.cn/kZtyGX',
    'courewarepreview'=>'https://static.ifaclub.cn/ifaClass/detail.html?coursewareid=', //方舟课堂预览 钱礼骏
    'FinanceProductBenefitRateUrl'=>'https://static.ifaclub.cn',//H5业绩比较基准  彭斌
    'courewarePwd' => 'ifaclub',//优酷视频的密码 --郭士魁
    'jtpay_notification' => [ //金通对账 手机提醒
        'cwq7411' => 18616733373,
    ],
    'bankIcon' => 'https://dn-ifa-static.qbox.me/images/bank/',

    //强制更新的配置(1.3.0版本及以下强制升级)
    'forceUpdateVersionSetting' => [
        'android' => [
            'user' => [
                'com.noah.ifa.app.standard' => 72,
            ],
            'ifa' => [
                'com.noah.ifa.app.pro' => 72,
            ]
        ],
        'ios' => [
            'user' => [
                'com.ifa.app.inHouse.std' => 1507315,
                'com.ifa.app.std' => 1512052,
            ],
            'ifa' => [
                'com.ifa.app.inHouse.pro' => 1507177,
                'com.ifa.app.pro' => 1511026,
            ]
        ],

        'isEnabled' => true,

    ],

    //可信反代whitelist
    'trustedProxies' => [
        '10.3.33.22',
        '10.3.210.23',
        '10.21.40.53',
        '10.3.212.45',
        '127.0.0.1',
    ],

    //java系统接口配置
    'javaSystem' => [
        'url' => 'http://backend.ifaclub.cn/settle/gateway',
        'javaCashUrl' => 'http://backend.ifaclub.cn/app/gateway',// 目前现金宝 added by pengying
        'enable_white_list' => true,
        'ip_white_list' => [
            '10.21.40.60',
            '10.21.40.61',
            '10.3.33.190',
            '10.3.33.191',
            '10.3.33.192',
            '10.3.33.22',
            '10.21.40.53'
        ],

        // 找java同学配置,书伟
        
        'insuranceUrl' => 'http://backend.ifaclub.cn/order/gateway',
        'stockUrl' => 'http://backend.ifaclub.cn/order/gateway',
        'productSearchUrl' => 'http://backend.ifaclub.cn/search/gateway',
        'productUploadUrl' => 'http://backend.ifaclub.cn/search-master/gateway',
        'faMessageUrl' => 'http://backend.ifaclub.cn/message/gateway', //消息中心的url
        'javaCashUrl' => 'http://backend.ifaclub.cn/app/gateway',// 目前现金宝
        'contractBuildPdfUrl' => 'http://backend.ifaclub.cn/econtract/gateway', // 
    ],

    'hr_sql_server' => [
        'host' => 'KS-UAT-SQL01',
        'username' => 'hr_o2o_sit',//hr_o2o_sit
        'password' => 'hr_o2o_sit',
        'db' => 'NOAHHR_20150618',
        'encrypt' => false
    ],

    'editor_mobiles' => [
        '18601771621',
        '18857881532',
        '15221808925',
        '18616803002',
        '18616910645',
        '15618273535',
        '13917868488',
        '18621378781',
    ],

    'insurance_intro_url' => [
        'U2001' => 'https://static.ifaclub.cn/nocache/usernotice1.html',
        'U2005' => 'https://static.ifaclub.cn/nocache/usernotice3.html'
    ],
	//是否启用新联行号流程开关  -- 郭士魁
	'isEnabledBranchBank' => true,
    'isEnabledCloudCC'=> true, // 钱礼骏
    //天保盈产品代码 -- 王福星
    'insurance_tianbao' => [
                '10404002'
    ],

    //ftp config
    'sftp' => [
        'host' => 'worker.ifaclub.cn',
        'username' => 'filetran',
        'password' => 'filetran@noahwm',
    ],

    //前海人寿产品代码
    'insurance_qianhai' => [
        'U2001',
        'U2005'
    ],
    'insurance_qianhai_notice' => '• 本人同意身故保险金受益人为法定受益人$$• 本人承诺所填写各项信息均真实完整，知晓并同意贵公司采集本人信息为本人提供计算保费、核保、发送保险合同信息等服务之用。如因信息不完整或不真实而导致本人权益受损，贵公司无需承担责任。如果本人信息发生变更，将及时至贵公司办理更正手续。贵公司承诺未经本人同意或授权，不会将本人的信息用于贵公司和第三方的销售活动。$$• 本人已阅读保险产品的条款，了解条款中保险责任、责任免除、犹豫期及退保费用等内容，本人愿意根据全部条款的约定投保。$$• 本人已阅读保险条款、产品说明书和投保提示书，了解本产品的特点和保单利益的不确定性。同意将接收电子保单日作为保单合同签收日。同意如发生有关网上投保险种、保险金额等方面的分歧，以贵公司的电子记录凭证等数据电文作为判断本保险合同的唯一合法有效证，该凭证具有完全证据效力。',
];