# Change Log
All notable changes to this project will be documented in this file based on the
[Keep a Changelog](http://keepachangelog.com/) Standard.

## [Unreleased](https://github.com/elastic/libbeat/compare/1.0.0-rc1...HEAD)

### Backward Compatibility Breaks

### Deprecated

### Added
- Add a dashboard for Windows Event Log statistics with data from Winlogbeat #60

### Bugfixes

## [1.0.0-rc1](https://github.com/elastic/libbeat/compare/1.0.0-beta4...1.0.0-rc1)

### Backward Compatibility Breaks

### Deprecated

### Bugfixes

### Added
- Update index patterns, dashboards after replacing timestamp with @timestamp

